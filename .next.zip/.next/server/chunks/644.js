"use strict";
exports.id = 644;
exports.ids = [644];
exports.modules = {

/***/ 55644:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ WordsAnimation)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(94945);



function WordsAnimation({ text , tag , className  }) {
    const words = text.split(" ");
    const container = {
        hidden: {
            opacity: 0
        },
        visible: (i = 1)=>({
                opacity: 1,
                transition: {
                    staggerChildren: 0.12,
                    delayChildren: 0.04 * i
                }
            })
    };
    const child = {
        visible: {
            opacity: 1,
            x: 0,
            transition: {
                type: "spring",
                damping: 12,
                stiffness: 100
            }
        },
        hidden: {
            opacity: 0,
            x: 20,
            transition: {
                type: "spring",
                damping: 12,
                stiffness: 100
            }
        }
    };
    if (tag === "h1") {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__/* .motion.h1 */ .E.h1, {
            className: `${className}`,
            variants: container,
            initial: "hidden",
            animate: "visible",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Item, {
                words: words,
                child: child,
                className: className
            })
        });
    } else if (tag === "h2") {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__/* .motion.h2 */ .E.h2, {
            className: `${className}`,
            variants: container,
            initial: "hidden",
            animate: "visible",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Item, {
                words: words,
                child: child,
                className: className
            })
        });
    } else if (tag === "h3") {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__/* .motion.h3 */ .E.h3, {
            className: `${className}`,
            variants: container,
            initial: "hidden",
            animate: "visible",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Item, {
                words: words,
                child: child,
                className: className
            })
        });
    } else if (tag === "h4") {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__/* .motion.h4 */ .E.h4, {
            className: `${className}`,
            variants: container,
            initial: "hidden",
            animate: "visible",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Item, {
                words: words,
                child: child,
                className: className
            })
        });
    } else if (tag === "h5") {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__/* .motion.h5 */ .E.h5, {
            className: `${className}`,
            variants: container,
            initial: "hidden",
            animate: "visible",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Item, {
                words: words,
                child: child,
                className: className
            })
        });
    } else if (tag === "h6") {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__/* .motion.h6 */ .E.h6, {
            className: `${className}`,
            variants: container,
            initial: "hidden",
            animate: "visible",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Item, {
                words: words,
                child: child,
                className: className
            })
        });
    } else {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__/* .motion.p */ .E.p, {
            className: `${className} `,
            variants: container,
            initial: "hidden",
            animate: "visible",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Item, {
                words: words,
                child: child,
                className: className
            })
        });
    }
}
function Item({ words , child , className  }) {
    return words.map((word, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_2__/* .motion.span */ .E.span, {
            variants: child,
            style: {
                marginRight: "5px"
            },
            className: `${className} inline-flex`,
            children: word + "\xa0"
        }, index));
}


/***/ })

};
;