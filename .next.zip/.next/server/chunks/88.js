exports.id = 88;
exports.ids = [88];
exports.modules = {

/***/ 87040:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 89446, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 43258, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 56862, 23))

/***/ }),

/***/ 9867:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 38928));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 60278));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 27753))

/***/ }),

/***/ 13259:
/***/ (() => {



/***/ }),

/***/ 52300:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(14353);
module.exports = createProxy("C:\\Users\\LEUM_\\Desktop\\Tangle\\Tangle-Offline-website-2023\\app\\components\\footer\\Footer.jsx");


/***/ }),

/***/ 6990:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(14353);
module.exports = createProxy("C:\\Users\\LEUM_\\Desktop\\Tangle\\Tangle-Offline-website-2023\\app\\components\\navbar\\NavBar.jsx");


/***/ }),

/***/ 49447:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(14353);
module.exports = createProxy("C:\\Users\\LEUM_\\Desktop\\Tangle\\Tangle-Offline-website-2023\\app\\context\\languageContext.jsx");


/***/ }),

/***/ 22725:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Head)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(88499);

function Head({ params  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                children: "Tangle Offline"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                content: "width=device-width, initial-scale=1",
                name: "viewport"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                rel: "icon",
                href: "/favicon.ico"
            })
        ]
    });
}


/***/ }),

/***/ 11977:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ RootLayout)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(88499);
/* harmony import */ var _head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(22725);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(46495);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _context_languageContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(49447);
/* harmony import */ var _context_languageContext__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_context_languageContext__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_navbar_NavBar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6990);
/* harmony import */ var _components_navbar_NavBar__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_components_navbar_NavBar__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_footer_Footer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(52300);
/* harmony import */ var _components_footer_Footer__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_components_footer_Footer__WEBPACK_IMPORTED_MODULE_5__);






function RootLayout({ children  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("html", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_head__WEBPACK_IMPORTED_MODULE_1__["default"], {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("body", {
                className: "bg-tangle-rich-black-FOGBRA-29 text-white font-body grid grid-cols-1 ",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_context_languageContext__WEBPACK_IMPORTED_MODULE_3__.LanguageProvider, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                            className: "max-w-full z-50",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_components_navbar_NavBar__WEBPACK_IMPORTED_MODULE_4___default()), {})
                        }),
                        children,
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
                            className: "max-w-full",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_components_footer_Footer__WEBPACK_IMPORTED_MODULE_5___default()), {})
                        })
                    ]
                })
            })
        ]
    });
}


/***/ }),

/***/ 27753:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Footer)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _context_languageContext__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(38928);



function Footer() {
    const { text  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_languageContext__WEBPACK_IMPORTED_MODULE_2__.LanguageContext);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("footer", {
        className: "flex flex-col text-sm md:text-base content-around align-middle text-center pb-16 max-w-full justify-around",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                children: [
                    text.footer[0].webside,
                    " | ",
                    text.footer[0].rights,
                    " | \xa0",
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                        href: text.footer[0].policy_pathname,
                        children: [
                            text.footer[0].policy,
                            " | \xa0"
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                        href: `mailto:${text.footer[0].email}`,
                        children: text.footer[0].email
                    })
                ]
            })
        })
    });
}


/***/ }),

/***/ 34144:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CountrySelector)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(71031);
/* harmony import */ var react_flags_select__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16787);




function CountrySelector({ className , text , navbar  }) {
    const [emailForm, setEmailForm] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [formSubmit, setFormSubmit] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [submitted, setSubmitted] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [stepOne, setStepOne] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [stepTwo, setStepTwo] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [stepThree, setStepThree] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { control  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__/* .useForm */ .cI)();
    const [country, setCountry] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    /* submit form */ const handleEmailInput = (e)=>{
        setFormSubmit(e.target.value);
    };
    const handleSubmit = (e)=>{
        e.preventDefault();
    /* send form data to which service? */ };
    /* button submitted */ const submittedForm = ()=>{
        setSubmitted(!submitted);
        setTimeout(()=>{
            setSubmitted(!submitted);
        }, 500);
    };
    const handleSteps = ()=>{
        if (!stepThree && stepTwo && stepOne) setStepThree(true);
        if (!stepTwo && stepOne) setStepTwo(true);
        if (!stepOne) setStepOne(true);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: `flex justify-center rounded-lg  ${className || "w-3/4 md:w-3/5 lg:w-2/5"} self-center`,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_hook_form__WEBPACK_IMPORTED_MODULE_3__/* .Controller */ .Qr, {
                    name: "country",
                    control: control,
                    rules: {
                        required: true
                    },
                    render: ({ field: { onChange , value  }  })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_flags_select__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .ZP, {
                            className: `bg-white h-11 text-black rounded-lg border border-solid border-zinc-400 my-2 ${navbar && "mobile-navbar"}`,
                            selected: country,
                            onClick: ()=>setEmailForm(!emailForm),
                            searchable: true,
                            onSelect: (code, emailForm)=>{
                                onChange((emailForm)=>{
                                    setEmailForm(!emailForm);
                                });
                                setCountry(code);
                            },
                            value: value
                        })
                })
            }),
            emailForm && !navbar && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                onSubmit: handleSubmit,
                className: "mt-12 flex align-middle self-center content-center justify-center lg:w-7/12 ",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        className: `flex w-3/5 lg:w-4/5 flex-row items-center gap-2 rounded-l-3xl py-3 px-3 lg:px-32  ${submitted ? "email-input-after hidden" : "email-input font-bold text-xl text-gray-700 border-none gap-2 "}`,
                        placeholder: text.placeholder,
                        type: "email",
                        id: "email",
                        name: "email",
                        onChange: handleEmailInput
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: `flex w-2/5 lg:w-1/5 row items-center justify-center border-none font-bold py-3 px-3 lg:px-36 bg-tangle-green-blue-crayola  hover:text-white hover:bg-tangle-cyan-process cursor-pointer ${submitted ? "btn-submitted self-center rounded-full" : "btn text-xl text-white flex rounded-r-3xl"}`,
                        type: "submit",
                        onClick: submittedForm,
                        children: submitted ? `✓ ${text.submited}` : text.button
                    })
                ]
            }),
            emailForm && stepOne && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                onSubmit: handleSubmit,
                className: "flex align-middle self-center content-center justify-center lg:w-7/12 ",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    className: `my-4 flex w-full rounded-lg border border-solid border-zinc-400  flex-row items-center  py-3 px-3  ${submitted ? "email-input-after hidden" : "email-input text-xl text-gray-700"}`,
                    placeholder: text.placeholder,
                    type: "email",
                    id: "email",
                    name: "email",
                    onChange: handleEmailInput
                })
            }),
            navbar && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                className: `mt-2 mb-8 disabled:bg-slate-400 rounded-full flex w-full row items-center justify-center border-none font-bold py-3 px-3 lg:px-36 bg-tangle-green-blue-crayola  hover:text-white hover:bg-tangle-cyan-process cursor-pointer ${submitted ? "btn-submitted self-center" : "btn text-xl text-white flex"}`,
                type: "submit",
                disabled: !emailForm,
                onClick: handleSteps,
                children: getText(stepOne, stepTwo, text)
            })
        ]
    });
}
function getText(stepOne, stepTwo, text) {
    if (!stepOne) {
        return "Next";
    }
    if (!stepTwo && stepOne) {
        return text.button;
    }
    if (stepTwo && stepOne) {
        return text.submited;
    }
}


/***/ }),

/***/ 60278:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ NavBar)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/utils/use-cycle.mjs + 1 modules
var use_cycle = __webpack_require__(3694);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/dom/motion.mjs + 144 modules
var motion = __webpack_require__(94945);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs + 2 modules
var AnimatePresence = __webpack_require__(45543);
;// CONCATENATED MODULE: ./app/components/navbar/hook/use-dimensions.jsx

// Naive implementation - in reality would want to attach
// a window or resize listener. Also use state/layoutEffect instead of ref/effect
// if this is important to know on initial client render.
// It would be safer to  return null for unmeasured states.
const useDimensions = (ref)=>{
    const dimensions = (0,react_.useRef)({
        width: 0,
        height: 0
    });
    (0,react_.useEffect)(()=>{
        dimensions.current.width = ref.current.offsetWidth;
        dimensions.current.height = ref.current.offsetHeight;
    }, []);
    return dimensions.current;
};

;// CONCATENATED MODULE: ./app/components/navbar/toggle-menu/ToggleMenu.jsx



const Path = (props)=>/*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
        fill: "transparent",
        strokeWidth: "3",
        stroke: "hsl(0, 0%, 18%)",
        strokeLinecap: "round",
        ...props
    });
const ToggleMenu = ({ toggle , isOpen  })=>/*#__PURE__*/ jsx_runtime_.jsx("button", {
        className: `flex items-center justify-center ${isOpen ? "fixed" : "absolute"} top-5 right-9 w-12 h-12 rounded-full bg-transparent`,
        onClick: toggle,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
            width: "23",
            height: "23",
            viewBox: "0 0 23 28",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(Path, {
                    variants: {
                        closed: {
                            d: "M 2 2.5 L 20 2.5",
                            stroke: "rgb(255,255,255)",
                            transition: {
                                delay: 0.5
                            }
                        },
                        open: {
                            d: "M 3 16.5 L 17 2.5",
                            stroke: "rgb(0,0,0)"
                        }
                    }
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Path, {
                    d: "M 2 9.423 L 20 9.423",
                    variants: {
                        closed: {
                            opacity: 1,
                            stroke: "rgb(255,255,255)",
                            transition: {
                                delay: 0.5
                            }
                        },
                        open: {
                            opacity: 0,
                            stroke: "rgb(0,0,0)"
                        }
                    },
                    transition: {
                        duration: 0.1
                    }
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Path, {
                    variants: {
                        closed: {
                            d: "M 2 16.346 L 20 16.346",
                            stroke: "rgb(255,255,255)",
                            transition: {
                                delay: 0.5
                            }
                        },
                        open: {
                            d: "M 3 2.5 L 17 16.346",
                            stroke: "rgb(0,0,0)"
                        }
                    }
                })
            ]
        })
    });

// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/utils/use-in-view.mjs
var use_in_view = __webpack_require__(93978);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(59483);
;// CONCATENATED MODULE: ./app/components/navbar/sub-menu/SubMenu.jsx



function SubMenu({ isOpen , subIsOpen , setIsOpenList , categories , name , itemVariants , className  }) {
    const pathname = (0,navigation.usePathname)();
    const currentLanguage = categories.filter((category)=>pathname.includes(category.pathname));
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.ul */.E.ul, {
            variants: itemVariants,
            initial: false,
            animate: isOpen ? "open" : "closed",
            whileTap: {
                scale: 0.97
            },
            whileHover: {
                color: "black"
            },
            className: `text-center  font-bold  w-full content-center ${className}`,
            onClick: ()=>setIsOpenList(!subIsOpen),
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex justify-between align-middle items-center hover:text-tangle-green-blue-crayola",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "hover:text-tangle-green-blue-crayola ",
                            children: name
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: `${subIsOpen ? "rotate-90" : ""}`,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                width: "8",
                                height: "15",
                                viewBox: "0 0 8 15",
                                fill: "none",
                                xmlns: "http://www.w3.org/2000/svg",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    className: "hover:stroke-tangle-green-blue-crayola",
                                    d: "M1 13.5L7 7.5L1 1.5",
                                    stroke: "#0D111B",
                                    strokeWidth: "2",
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round"
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(AnimatePresence/* AnimatePresence */.M, {
                    children: isOpen && subIsOpen && categories.map((category, index)=>/*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.li */.E.li, {
                            variants: itemVariants,
                            initial: "closed",
                            animate: isOpen ? "open" : "closed",
                            exit: "closed",
                            className: "text-left border-b-2 hover:text-tangle-green-blue-crayola text-neutral-600 font-normal mt-5 flex-row w-full content-center justify-center",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                href: `${currentLanguage[0].pathname === category.pathname ? pathname : category.pathname + pathname.slice(3)}`,
                                className: `${currentLanguage[0].pathname === category.pathname ? "text-tangle-green-blue-crayola" : ""}`,
                                children: [
                                    " ",
                                    category.name,
                                    " "
                                ]
                            })
                        }, index))
                })
            ]
        })
    });
}
/* harmony default export */ const sub_menu_SubMenu = (SubMenu);

// EXTERNAL MODULE: ./app/components/forms/CountrySelector.jsx
var CountrySelector = __webpack_require__(34144);
// EXTERNAL MODULE: ./app/context/languageContext.jsx + 1 modules
var languageContext = __webpack_require__(38928);
;// CONCATENATED MODULE: ./app/components/navbar/main-menu/MainMenu.jsx






const MainMenu = ({ isOpen  })=>{
    const [isOpenGeneral, setIsOpenGeneral] = (0,react_.useState)(false);
    const { text  } = (0,react_.useContext)(languageContext.LanguageContext);
    const ref = (0,react_.useRef)(null);
    const isInView = (0,use_in_view/* useInView */.Y)(ref, {
        once: false
    });
    const itemVariants = {
        open: (i = 1)=>({
                opacity: 1,
                y: 0,
                transition: {
                    type: "spring",
                    stiffness: 400,
                    damping: 40,
                    staggerChildren: 1 * i,
                    delayChildren: 0.75 * i,
                    when: "beforeChildren"
                }
            }),
        closed: {
            y: 50,
            opacity: 0,
            transition: {
                type: "spring",
                stiffness: 400,
                damping: 40,
                staggerChildren: 1,
                staggerDirection: -1,
                when: "afterChildren"
            }
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.ul */.E.ul, {
        variants: itemVariants,
        initial: "closed",
        animate: isOpen ? "open" : "closed",
        exit: "closed",
        className: "flex-row group-first:border-b-2 content-center justify-center top-[75px] right-0 px-14 fixed w-full",
        ref: ref,
        children: /*#__PURE__*/ jsx_runtime_.jsx(AnimatePresence/* AnimatePresence */.M, {
            children: isOpen && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.a */.E.a, {
                        variants: itemVariants,
                        initial: "closed",
                        animate: isOpen && isInView ? "open" : "closed",
                        exit: "closed",
                        href: text.menu[0].home_pathname,
                        className: "block text-center text-tangle-rich-black-FOGBRA-29 font-bold hover:text-tangle-green-blue-crayola",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex justify-between align-middle items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: text.menu[0].home
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    width: "8",
                                    height: "15",
                                    viewBox: "0 0 8 15",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        className: "hover:stroke-tangle-green-blue-crayola",
                                        d: "M1 13.5L7 7.5L1 1.5",
                                        stroke: "#0D111B",
                                        strokeWidth: "2",
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round"
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.a */.E.a, {
                        variants: itemVariants,
                        initial: "closed",
                        animate: isOpen ? "open" : "closed",
                        exit: "closed",
                        href: text.menu[0].merchant_pathname,
                        className: "block mt-5 text-center text-tangle-rich-black-FOGBRA-29 font-bold hover:text-tangle-green-blue-crayola",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex justify-between align-middle items-center",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: text.menu[0].merchant
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    width: "8",
                                    height: "15",
                                    viewBox: "0 0 8 15",
                                    fill: "none",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        className: "hover:stroke-tangle-green-blue-crayola",
                                        d: "M1 13.5L7 7.5L1 1.5",
                                        stroke: "#0D111B",
                                        strokeWidth: "2",
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round"
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                        variants: itemVariants,
                        initial: "closed",
                        animate: isOpen ? "open" : "closed",
                        exit: "closed",
                        className: "hover:text-tangle-green-blue-crayola cursor-pointer",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(sub_menu_SubMenu, {
                            itemVariants: itemVariants,
                            isOpen: isOpen,
                            initial: "closed",
                            animate: isOpen ? "open" : "closed",
                            exit: "closed",
                            subIsOpen: isOpenGeneral,
                            setIsOpenList: setIsOpenGeneral,
                            name: text.menu[0].languages,
                            categories: text.menu[0].languages_options,
                            className: "mt-5 text-tangle-rich-black-FOGBRA-29 hover:stroke-tangle-green-blue-crayola"
                        })
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const main_menu_MainMenu = (MainMenu);

// EXTERNAL MODULE: ./app/components/ui/select-list/Select.css
var Select = __webpack_require__(72508);
;// CONCATENATED MODULE: ./app/components/ui/select-list/SelectList.js






const itemVariants = {
    open: (i = 1)=>({
            opacity: 1,
            y: 0,
            transition: {
                type: "spring",
                stiffness: 400,
                damping: 40,
                staggerChildren: 1
            }
        }),
    closed: {
        y: 50,
        opacity: 0,
        transition: {
            type: "spring",
            stiffness: 400,
            damping: 40,
            staggerChildren: 1,
            staggerDirection: -1
        }
    }
};
const mobileNavbar = {
    open: {
        clipPath: "inset(0% 0% 0% 0% round 10px)",
        transition: {
            type: "spring",
            bounce: 0,
            duration: 0.7,
            delayChildren: 0.3,
            staggerChildren: 0.05
        }
    },
    closed: {
        clipPath: "inset(10% 50% 90% 50% round 10px)",
        transition: {
            type: "spring",
            bounce: 0,
            duration: 0.3
        }
    }
};
function SelectList() {
    const { text  } = (0,react_.useContext)(languageContext.LanguageContext);
    const [isOpen, setIsOpen] = (0,react_.useState)(false);
    const pathname = (0,navigation.usePathname)();
    const currentLanguage = text.menu[0].languages_options.filter((category)=>pathname.includes(category.pathname));
    const [selectedCategory, setSelectedCategory] = (0,react_.useState)(text.menu[0].current_language);
    const languageOptions = text.menu[0].languages_options;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.nav */.E.nav, {
        initial: false,
        animate: isOpen ? "open" : "closed",
        className: " flex flex-col self-center",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.button */.E.button, {
                whileTap: {
                    scale: 0.97
                },
                onClick: ()=>setIsOpen(!isOpen),
                className: "select-list relative cursor-pointer w-full flex justify-between items-center text-left ",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "self-center",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                            width: "24",
                            height: "24",
                            viewBox: "0 0 24 24",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    d: "M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z",
                                    stroke: "white",
                                    strokeWidth: "2",
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    d: "M2 12H22",
                                    stroke: "white",
                                    strokeWidth: "2",
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    d: "M12 2C14.5013 4.73835 15.9228 8.29203 16 12C15.9228 15.708 14.5013 19.2616 12 22C9.49872 19.2616 8.07725 15.708 8 12C8.07725 8.29203 9.49872 4.73835 12 2V2Z",
                                    stroke: "white",
                                    strokeWidth: "2",
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "fs-6 fw-normal text-secondary mx-2 font-semibold ",
                        children: selectedCategory || "Language"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                        variants: {
                            open: {
                                rotate: 180
                            },
                            closed: {
                                rotate: 0
                            }
                        },
                        transition: {
                            duration: 0.2
                        },
                        style: {
                            originY: 0.55
                        },
                        className: "select-list",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                            width: "14",
                            height: "8",
                            viewBox: "0 0 14 8",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                d: "M1 1L7 7L13 1",
                                stroke: "white",
                                strokeWidth: "2",
                                strokeLinecap: "round",
                                strokeLinejoin: "round"
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(AnimatePresence/* AnimatePresence */.M, {
                children: isOpen && /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.ul */.E.ul, {
                    variants: mobileNavbar,
                    className: `select-list w-28 absolute bg-white top-16 right-8 ${isOpen ? "p-2" : "hidden"}`,
                    exit: "closed",
                    style: {
                        pointerEvents: isOpen ? "auto" : "none"
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx(AnimatePresence/* AnimatePresence */.M, {
                        children: isOpen && /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                            children: languageOptions && languageOptions.map((category, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.li */.E.li, {
                                    className: "text-center text-base last:border-b-0 border-b-2 text-neutral-600 font-normal first:mt-0 mt-2 flex-row w-full content-center justify-center",
                                    whileHover: {
                                        color: "rgb(24,31,49)",
                                        fontSize: "18px"
                                    },
                                    whileTap: {
                                        color: "rgb(24,31,49)",
                                        fontSize: "14px"
                                    },
                                    variants: itemVariants,
                                    initial: "closed",
                                    animate: isOpen ? "open" : "closed",
                                    exit: "closed",
                                    value: category.id,
                                    onClick: ()=>{
                                        setIsOpen(false);
                                    },
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                            href: `${currentLanguage[0].pathname === category.pathname ? pathname : category.pathname + pathname.slice(3)}`,
                                            className: `${currentLanguage[0].pathname === category.pathname ? "text-tangle-green-blue-crayola" : ""}`,
                                            children: [
                                                " ",
                                                category.name,
                                                " "
                                            ]
                                        }),
                                        console.log(currentLanguage[0].pathname, category.pathname, pathname, category.pathname + pathname.slice(3), category.name)
                                    ]
                                }, index))
                        })
                    })
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./app/components/navbar/NavBar.jsx









const sidebar = {
    open: {
        clipPath: "inset(0 0 0 0%)",
        transition: {
            type: "spring",
            stiffness: 40,
            restDelta: 1,
            duration: 5,
            when: "beforeChildren"
        }
    },
    closed: {
        clipPath: "inset(0 0 0 100%)",
        transition: {
            type: "spring",
            stiffness: 40,
            restDelta: 1,
            duration: 5,
            when: "afterChildren"
        }
    }
};
function NavBar() {
    const { text  } = (0,react_.useContext)(languageContext.LanguageContext);
    const [isOpen, toggleOpen] = (0,use_cycle/* useCycle */.n)(false, true);
    const containerRef = (0,react_.useRef)(null);
    const { height  } = useDimensions(containerRef);
    const [scrolled, setScrolled] = (0,react_.useState)(false);
    (0,react_.useEffect)(()=>{
        window.addEventListener("scroll", handleScroll);
        return ()=>{
            window.removeEventListener("scroll", handleScroll);
        };
    }, []);
    const handleScroll = ()=>{
        if (window.pageYOffset > 0) {
            setScrolled(true);
        } else {
            setScrolled(false);
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "top-0 z-50 w-full opacity-100",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            style: {
                transitionDuration: "600ms",
                transitionProperty: "all",
                transitionTimingFunction: "cubic-bezier(0.4, 0, 0.2, 1)"
            },
            className: `flex h-20 absolute justify-between md:fixed top-0 w-full ${scrolled ? "bg-opacity-50 bg-tangle-oxford-blue" : ""}`,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: " ml-8 col-span-2 flex justify-center items-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                        href: text.menu[0].home_pathname,
                        className: "w-full self-center",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.img */.E.img, {
                            layoutId: "navbarLogo",
                            src: "/logos/TangleLogoNewWhite.png",
                            alt: "Tangle Logo",
                            width: "150px",
                            height: "auto"
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "hidden md:flex",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex justify-center px-4",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                href: text.home[12].button_url,
                                className: "self-center",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.button */.E.button, {
                                    className: "bg-[#0086D3] rounded-full py-3 px-5 h-12 self-center",
                                    children: text.home[12].button
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex justify-center pr-8 pl-4",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(SelectList, {})
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.nav */.E.nav, {
                    initial: false,
                    animate: isOpen ? "open" : "closed",
                    custom: height,
                    ref: containerRef,
                    className: "absolute md:hidden top-0 right-0 bottom-0 w-full",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(AnimatePresence/* AnimatePresence */.M, {
                            children: isOpen && /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.div */.E.div, {
                                    className: `fixed h-screen top-0 right-0 bottom-0 max-w-full overflow-hidden ${isOpen ? "bg-white w-screen" : "bg-white"} `,
                                    initial: "closed",
                                    animate: "open",
                                    exit: "closed",
                                    variants: sidebar,
                                    layout: true,
                                    layoutId: "sidebar",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(main_menu_MainMenu, {
                                            isOpen: isOpen
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.div */.E.div, {
                                            initial: {
                                                opacity: 0
                                            },
                                            animate: {
                                                opacity: 1
                                            },
                                            className: `${isOpen ? "fixed" : "hidden"} left-0 bottom-0 w-full px-14 transition-all`,
                                            transition: {
                                                duration: 0.1,
                                                delay: 1
                                            },
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "text-teal-800 invite-place-two font-semibold text-sm",
                                                    children: text.home[14].description
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(CountrySelector/* default */.Z, {
                                                    className: "w-full",
                                                    text: text.home[14],
                                                    navbar: true
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(ToggleMenu, {
                            isOpen: isOpen,
                            toggle: ()=>toggleOpen()
                        })
                    ]
                })
            ]
        })
    });
}


/***/ }),

/***/ 11296:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ LettersAnimation)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(94945);


function LettersAnimation({ text , tag , className , children  }) {
    const words = text.split(" ");
    if (tag === "h1") {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h1", {
            className: `${className}`,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Item, {
                words: words,
                className: className,
                children: children
            })
        });
    } else if (tag === "h2") {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
            className: `${className}`,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Item, {
                words: words,
                className: className,
                children: children
            })
        });
    } else if (tag === "h3") {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
            className: `${className}`,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Item, {
                words: words,
                className: className,
                children: children
            })
        });
    } else if (tag === "h4") {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
            className: `${className}`,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Item, {
                words: words,
                className: className,
                children: children
            })
        });
    } else if (tag === "h5") {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
            className: `${className}`,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Item, {
                words: words,
                className: className,
                children: children
            })
        });
    } else if (tag === "h6") {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
            className: `${className}`,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Item, {
                words: words,
                className: className,
                children: children
            })
        });
    } else {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
            className: `${className}`,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Item, {
                words: words,
                className: className,
                children: children
            })
        });
    }
}
function Item({ words , className , children  }) {
    const container = {
        hidden: {
            opacity: 0
        },
        visible: (i = 1)=>({
                opacity: 1,
                transition: {
                    staggerChildren: 0.15,
                    delayChildren: 0.5 * i
                }
            })
    };
    const child = {
        visible: {
            opacity: 1,
            x: 0,
            y: 0,
            transition: {
                type: "spring",
                damping: 12,
                stiffness: 100
            }
        },
        hidden: {
            opacity: 0,
            x: -20,
            y: 10,
            transition: {
                type: "spring",
                damping: 12,
                stiffness: 100
            }
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__/* .motion.span */ .E.span, {
                variants: container,
                initial: "hidden",
                animate: "visible",
                children: words.map((word, index)=>{
                    if (word === "<br/>") {
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}, index);
                    }
                    if (word === "<span>") {
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__/* .motion.span */ .E.span, {
                            variants: child,
                            className: "text-tangle-cyan-process",
                            children: words[index + 1]
                        }, index);
                    }
                    if (words[index - 1] === "<span>") {
                        return "";
                    }
                    if (word === "</span>") {
                        return "";
                    }
                    if (word === "<em>") {
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__/* .motion.em */ .E.em, {
                            variants: child,
                            children: words[index + 1]
                        }, index);
                    }
                    if (words[index - 1] === "<em>") {
                        return "";
                    }
                    if (word === "</em>") {
                        return "";
                    }
                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(framer_motion__WEBPACK_IMPORTED_MODULE_1__/* .motion.span */ .E.span, {
                        className: `${className} inline-flex mr-1 last:mr-0`,
                        children: [
                            word.split("").map((letter, i)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_1__/* .motion.span */ .E.span, {
                                    variants: child,
                                    className: "last:mr-0",
                                    children: letter
                                }, i)),
                            "\xa0"
                        ]
                    }, index);
                })
            }),
            children
        ]
    });
}


/***/ }),

/***/ 38928:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "LanguageContext": () => (/* binding */ LanguageContext),
  "LanguageProvider": () => (/* binding */ LanguageProvider)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: ./node_modules/next/navigation.js
var navigation = __webpack_require__(59483);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
;// CONCATENATED MODULE: ./app/data/text.json
const text_namespaceObject = JSON.parse('{"en":{"menu":[{"id":"en","current_language":"English","home":"Home","home_pathname":"/en","merchant":"Become a merchant","merchant_pathname":"/en/merchants","languages":"Languages","languages_options":[{"name":"English","pathname":"/en"},{"name":"Spanish","pathname":"/es"},{"name":"Dutch","pathname":"/nl"}]}],"footer":[{"webside":"© 2022 Tangle Offline","rights":"All rights reserved","policy":"Policy","policy_pathname":"/en/privacy-policy","email":"info@tangleoffline.com"}],"home":[{"section":1,"header":"The offline <br/> world wide web","subHeader":"A real-life social network to meet people, discover your city and engage in offline.","appleStore":"Comming Soon","appleStoreUrl":"#","playStore":"Comming Soon","playStoreUrl":"#"},{"section":2,"subHeader":"Tangle Offline is changing how people interact","header":"We bring <span> thousands </span> <br/> of people out to","activities":["Bowling","Cafe","Restaurant","Boat","Tour","Clubbling"]},{"section":3,"tittle":"Tangle video about what matters the most"},{"section":4,"header":"Problem","description":"Find people to hang out with, have social interactions, think creatively, and build strong communication skills. Do all of this, and more, on Tangle, by joining events and taking part in activities happening all around your city."},{"section":5,"headerCardOne":"160 times","descriptionCardOne":"a day an average person picks up a mobile phone","headerCardTwo":"2.5 hours","descriptionCardTwo":"spent on social media, 80% of people consider a waste of time","headerCardThree":"62 Days","descriptionCardThree":"A year wasted on social media and online entertainment"},{"section":6,"tv":"Tangle tv with parallax"},{"section":7,"subHeader":"Solution","header":"Focus on what matters","description":"Find people to hang out with, have social interactions, think creatively, and build strong communication skills. Do all of this, and more, on Tangle, by joining events and taking part in activities happening all around your city."},{"section":8,"headerCardOne":"Minimize digital interactions","headerCardTwo":"Join activities and events","headerCardThree":"Explore your city and discover new ones"},{"section":9,"map":"Tangle map with radar"},{"section":10,"subHeader":"Join existing events and create your own ","header":"Make lifelong  friends","description":"Find people to hang out with, have social interactions, think creatively, and build strong communication skills. Do all of this, and more, on Tangle, by joining events and taking part in activities happening all around your city."},{"section":11,"gallery":"Tangle gallery"},{"section":12,"subHeader":"Tangle Offline is changing how people interact","header":"We bring people out"},{"section":13,"header":"Partnering with <br/> Offline Businesses","description":"Our goal is simple, minimize your digital interactions on our platform, and maximize the time you spend offline. To do that, We engineered a set of features aiming to generate excitement toward meeting people in real life.","button":"Become a Merchant","button_url":"/en/merchants"},{"section":14,"gallery":["Create","Memories","Not","Just","Stories"]},{"section":15,"header":"Do you live in ","cities":["Amsterdam","Berlin","Barcelona","New York"],"description":"We will invite you to our next exclusive event","placeholder":"Your email","button":"Submit!","submited":"Submited"}],"merchant":[{"header":[{"text":"Be among the first ones!"},{"text":""}],"videoLink":"https://www.youtube.com/embed/hWHSanK6Rd4","lottieText":"Done","form":{"header":"Get started","body":[{"text":"Store name"},{"text":"Store address"},{"text":"Business type"},{"text":"Website link"},{"text":"Store KvK number (registration)"},{"text":"Name"},{"text":"Last name"},{"text":"Email address"},{"text":"Phone number"},{"text":"Share your feedback with us (Optional)"},{"text":"Submit"}]},"description":"We are helping Oflline Businesses go further. At Tangle we are doubling down on helping local commercial activities that revolve around offline social interactions to grow and prosper."}]},"es":{"menu":[{"id":"es","current_language":"Español","home":"Inicio","home_pathname":"/es","merchant":"Conviértase en comerciante","merchant_pathname":"/en/merchants","languages":"Lenguajes","languages_options":[{"name":"Inglés","pathname":"/en"},{"name":"Español","pathname":"/es"},{"name":"Neerlandés","pathname":"/nl"}]}],"footer":[{"webside":"© 2022 Tangle Offline","rights":"Todos los derechos reservados","policy":"Políticas","policy_pathname":"/es/privacy-policy","email":"info@tangleoffline.com"}],"home":[{"section":1,"header":"La red mundial <br/> offline","subHeader":"Una red social real para conocer gente, descubrir tu ciudad y participar en actividades offline.","appleStore":"Próximamente","appleStoreUrl":"#","playStore":"Próximamente","playStoreUrl":"#"},{"section":2,"subHeader":"Tangle Offline está cambiando la forma de relacionarse","header":"Traemos a <span> miles </span> <br/> de personas a","activities":["Boleras","Cafeterías","Restaurantes","Barcos","Excursiones","Clubbling"]},{"section":3,"tittle":"Vídeo sobre lo que más importa"},{"section":4,"header":"Problema","description":"Encuentra gente con la que pasar el rato, interactuar socialmente, pensar de forma creativa y desarrollar sólidas habilidades comunicativas. Haz todo esto y mucho más en Tangle, uniéndote a eventos y participando en actividades que se celebran por toda tu ciudad."},{"section":5,"headerCardOne":"160 veces","descriptionCardOne":"al día una persona media coge un teléfono móvil","headerCardTwo":"2,5 horas","descriptionCardTwo":"dedicadas a las redes sociales, que el 80% de las personas considera una pérdida de tiempo","headerCardThree":"62 días","descriptionCardThree":"Al año malgastados en redes sociales y entretenimiento online"},{"section":6,"tv":"Tangle tv con paralaje"},{"section":7,"subHeader":"Solución","header":"Centrarse en lo importante","description":"Encuentra gente con la que pasar el rato, interactuar socialmente, pensar de forma creativa y desarrollar sólidas habilidades comunicativas. Haz todo esto y mucho más en Tangle, uniéndote a eventos y participando en actividades que se celebran por toda tu ciudad."},{"section":8,"headerCardOne":"Minimiza las interacciones digitales","headerCardTwo":"Únete a actividades y eventos","headerCardThree":"Explora tu ciudad y descubre otras nuevas"},{"section":9,"map":"Mapa de Tangle"},{"section":10,"subHeader":"Únase a eventos existentes y cree los suyos propios","header":"Haz amigos para toda la vida","description":"Encuentra gente con la que pasar el rato, interactuar socialmente, pensar de forma creativa y desarrollar sólidas habilidades comunicativas. Haz todo esto y mucho más en Tangle, uniéndote a eventos y participando en actividades que se celebran por toda tu ciudad."},{"section":11,"gallery":"Galeria de Tangle"},{"section":12,"subHeader":"Tangle Offline está cambiando la forma de relacionarse","header":"Sacamos a la gente"},{"section":13,"header":"Asociación con empresas <br/> fuera de línea","description":"Nuestro objetivo es sencillo: minimizar tus interacciones digitales en nuestra plataforma y maximizar el tiempo que pasas fuera de ella. Para ello, hemos diseñado una serie de funciones que te ayudarán a conocer gente en la vida real.","button":"Conviértase en comerciante","button_url":"/es/merchants"},{"section":14,"gallery":["Crea","Recuerdos","No","Solo","Historias"]},{"section":15,"header":"¿Vives en ","cities":["Amsterdam","Berlín","Barcelona","Nueva York"],"description":"Le invitaremos a nuestro próximo evento exclusivo","placeholder":"Tu correo electrónico","button":"¡Envíalo!","submited":"Envíado"}],"merchant":[{"header":[{"text":"¡Se uno de nosotros!"},{"text":""}],"videoLink":"https://www.youtube.com/embed/hWHSanK6Rd4","lottieText":"Listo","form":{"header":"Comencemos","body":[{"text":"Nombre de la tienda"},{"text":"Dirección de la tienda"},{"text":"Tipo de negocio"},{"text":"Enlace web"},{"text":"Numero de tienda KvK (registro)"},{"text":"Nombre"},{"text":"Apellido"},{"text":"Dirección de correo"},{"text":"Numero de teléfono"},{"text":"Comparte tu opinión con nosotros (opcional)"},{"text":"Enviar"}]},"description":"Estamos ayudando a los negocios offline a llegar más lejos. En Tangle estamos redoblando nuestros esfuerzos para ayudar a crecer y prosperar a las actividades comerciales locales que giran en torno a las interacciones sociales fuera de línea."}]},"nl":{"menu":[{"id":"nl","current_language":"Nederlands","home":"Home","home_pathname":"/nl","merchant":"Handelaar worden","merchant_pathname":"/nl/merchants","languages":"Talen","languages_options":[{"name":"Engels","pathname":"/en"},{"name":"Spaans","pathname":"/es"},{"name":"Nederlands","pathname":"/nl"}]}],"footer":[{"webside":"© 2022 Tangle Offline","rights":"Alle rechten voorbehouden","policy":"Beleid","policy_pathname":"/nl/privacy-policy","email":"info@tangleoffline.com"}],"home":[{"section":1,"header":"Het offline <br/> wereld wijde web","subHeader":"Een real-life sociaal netwerk om mensen te ontmoeten, je stad te ontdekken en je offline in te zetten.","appleStore":"Binnenkort","appleStoreUrl":"#","playStore":"Binnenkort","playStoreUrl":"#"},{"section":2,"subHeader":"Tangle Offline verandert hoe mensen met elkaar omgaan","header":"We brengen <span> duizenden </span> <br/> mensen naar","activities":["Bowling","Café","Restaurant","Boot","Tour","Clubbling"]},{"section":3,"tittle":"Tangle video over wat het belangrijkst is"},{"section":4,"header":"Probleem","description":"Vind mensen om mee om te gaan, heb sociale interacties, denk creatief, en bouw sterke communicatieve vaardigheden op. Doe dit alles, en meer, op Tangle, door deel te nemen aan evenementen en activiteiten in je stad."},{"section":5,"headerCardOne":"160 keer","descriptionCardOne":"een gemiddelde persoon per dag een mobiele telefoon pakt","headerCardTwo":"2.5 uur","descriptionCardTwo":"besteed aan sociale media, beschouwt 80% van de mensen als tijdverspilling...","headerCardThree":"62 dagen","descriptionCardThree":"Een jaar verspild aan sociale media en online entertainment"},{"section":6,"tv":"Tangle tv met parallax"},{"section":7,"subHeader":"Oplossing","header":"Focus op wat belangrijk is","description":"Vind mensen om mee om te gaan, heb sociale interacties, denk creatief, en bouw sterke communicatieve vaardigheden op. Doe dit alles, en meer, op Tangle, door deel te nemen aan evenementen en activiteiten in je stad."},{"section":8,"headerCardOne":"Minimaliseer digitale interacties","headerCardTwo":"Deelnemen aan activiteiten en evenementen","headerCardThree":"Verken uw stad en ontdek nieuwe"},{"section":9,"map":"Klitkaart met radar"},{"section":10,"subHeader":"Neem deel aan bestaande evenementen en creëer uw eigen ","header":"Levenslange vrienden maken","description":"Vind mensen om mee om te gaan, heb sociale interacties, denk creatief, en bouw sterke communicatieve vaardigheden op. Doe dit alles, en meer, op Tangle, door deel te nemen aan evenementen en activiteiten in je stad."},{"section":11,"gallery":"Tangle galerij"},{"section":12,"subHeader":"Tangle Offline verandert hoe mensen met elkaar omgaan","header":"We brengen mensen naar buiten"},{"section":13,"header":"Samenwerking met <br/> offline bedrijven","description":"Ons doel is eenvoudig, het minimaliseren van uw digitale interacties op ons platform, en het maximaliseren van de tijd die u offline doorbrengt. Om dat te doen, hebben we een aantal functies ontworpen die erop gericht zijn mensen in het echt te ontmoeten.","button":"Handelaar worden","button_url":"/nl/merchants"},{"section":14,"gallery":["Creëer","herinneringen","niet","alleen","verhalen"]},{"section":15,"header":"Woont u in ","cities":["Amsterdam","Berlijn","Barcelona","New York"],"description":"We zullen u uitnodigen voor ons volgende exclusieve evenement","placeholder":"Uw e-mail","button":"Subtmit!","submited":"Ingezonden"}],"merchant":[{"header":[{"text":"Wees een van de eersten!"},{"text":""}],"videoLink":"https://www.youtube.com/embed/-4qMa7GmKio","lottieText":"Klaar","form":{"header":"Aan de slag","body":[{"text":"Naam winkel"},{"text":"Winkeladres"},{"text":"Type bedrijf"},{"text":"Website link"},{"text":"Store KvK number (registration)"},{"text":"Naam"},{"text":"Achternaam"},{"text":"E-mailadres"},{"text":"Telefoonnummer"},{"text":"Deel uw feedback met ons (optioneel)"},{"text":"Verzenden"}]},"description":"We helpen offline bedrijven verder te gaan. Bij Tangle verdubbelen we onze inspanningen om lokale commerciële ondernemingen die draaien om offline sociale interacties te helpen groeien en bloeien."}]}}');
// EXTERNAL MODULE: ./app/data/images.json
var data_images = __webpack_require__(28144);
// EXTERNAL MODULE: ./app/components/ui/animation/lettersAnimation.jsx
var lettersAnimation = __webpack_require__(11296);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/utils/use-in-view.mjs
var use_in_view = __webpack_require__(93978);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/components/LayoutGroup/index.mjs + 2 modules
var LayoutGroup = __webpack_require__(60229);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs + 2 modules
var AnimatePresence = __webpack_require__(45543);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/dom/motion.mjs + 144 modules
var motion = __webpack_require__(94945);
;// CONCATENATED MODULE: ./app/context/languageContext.jsx







const LanguageContext = /*#__PURE__*/ (0,react_.createContext)();
const LanguageProvider = ({ children  })=>{
    const pathname = (0,navigation.usePathname)();
    const [text, setText] = (0,react_.useState)(null);
    const [loading, setLoading] = (0,react_.useState)(true);
    const ref = (0,react_.useRef)(null);
    const isInView = (0,use_in_view/* useInView */.Y)(ref, {
        once: false
    });
    const container = {
        hidden: {
            opacity: 0
        },
        show: (i = 1)=>({
                opacity: 1,
                transition: {
                    staggerChildren: 1,
                    delayChildren: 0.25 * i
                }
            })
    };
    const child = {
        show: {
            opacity: 1,
            y: 0,
            scale: 1,
            transition: {
                ease: [
                    0.6,
                    0.1,
                    -0.05,
                    0.95
                ],
                duration: 3
            }
        },
        hidden: {
            opacity: 0,
            scale: 0,
            y: 200
        },
        exit: {
            opacity: 0,
            scale: 0,
            y: 0,
            x: 0
        }
    };
    (0,react_.useEffect)(()=>{
        const finalText = getText(pathname, text_namespaceObject);
        setText(finalText);
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(LayoutGroup/* LayoutGroup */.S, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(AnimatePresence/* AnimatePresence */.M, {
            children: loading || text === null ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.div */.E.div, {
                className: "h-screen grid grid-cols-1 align-middle justify-around overflow-hidden",
                variants: container,
                initial: "hidden",
                animate: isInView ? "show" : "hidden",
                ref: ref,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.img */.E.img, {
                        layout: true,
                        src: data_images/* logos.0 */.UN[0],
                        alt: "",
                        className: "w-1/4 self-end mx-auto ",
                        variants: child,
                        layoutId: "navbarLogo",
                        onAnimationComplete: ()=>{
                            setLoading(false);
                        },
                        onLayoutAnimationComplete: ()=>console.log("Done the animation")
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                        className: "max-w-full bg-transparent",
                        variants: child,
                        initial: "hidden",
                        animate: "show",
                        exit: "exit",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(lettersAnimation/* default */.Z, {
                            className: "text-center font-bold bg-transparent",
                            text: "Loading...",
                            tag: "p"
                        })
                    }, "Loading")
                ]
            }, "loader") : /*#__PURE__*/ jsx_runtime_.jsx(LanguageContext.Provider, {
                value: {
                    text
                },
                children: children
            })
        })
    });
// return <LanguageContext.Provider value={{ text }}>{children}</LanguageContext.Provider>
};
function getText(pathname, textData) {
    if (pathname.includes("/es")) {
        return textData.es;
    } else if (pathname.includes("/es")) {
        return textData.es;
    } else if (pathname.includes("/nl")) {
        return textData.nl;
    } else {
        return textData.en;
    }
}


/***/ }),

/***/ 72508:
/***/ (() => {



/***/ }),

/***/ 46495:
/***/ (() => {



/***/ }),

/***/ 28144:
/***/ ((module) => {

"use strict";
module.exports = JSON.parse('{"nu":["/collagePeople/pexels-caleb-oquendo-11140378.jpg","/collagePeople/pexels-sangeet-rao-5775283.jpg","/collagePeople/pexels-alessandro-kelvin-2376268.jpg","/collagePeople/top-view-from-colorful-stylish-happy-young-company-friends-lying-grass-park-man-women-having-fun-together.jpg","/collagePeople//pexels-mathias-pr-reding-4386145.jpg","/collagePeople/pexels-matheus-bertelli-8533826.jpg","/collagePeople/pexels-helena-lopes-745045.jpg"],"lH":["/circlesPeople/face1.png","/circlesPeople/face2.png","/circlesPeople/face3.png","/circlesPeople/face4.png","/circlesPeople/face5.png","/circlesPeople/face6.png","/circlesPeople/face7.png","/circlesPeople/face8.png","/circlesPeople/face9.png","/circlesPeople/face10.png","/circlesPeople/face11.png","/circlesPeople/face12.png","/circlesPeople/face13.png","/circlesPeople/face14.png","/circlesPeople/face15.png","/circlesPeople/face16.png"],"tS":["/activities/restaurant.jpeg","/activities/museum.jpeg","/activities/balloons.jpeg","/activities/castle.jpeg","/activities/stadium.jpeg"],"_u":["/activities/cards/card1.png","/activities/cards/card2.png","/activities/cards/card3.png","/activities/cards/card4.png","/activities/cards/card5.png","/activities/cards/card6.png","/activities/cards/card7.png","/activities/cards/card8.png","/activities/cards/card9.png"],"UN":["/logos/TangleLogoNewWhite.png"]}');

/***/ })

};
;