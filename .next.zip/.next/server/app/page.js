(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 53918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 64486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 99552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 3828:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_6__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_4__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_5__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_3__.staticGenerationAsyncStorage),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(72315);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62333);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(62885);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(90683);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(23269);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(85746);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8208);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_6__);

    const tree = {
      children: [
        '',
        {
      children: ['', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 91241, 23)), "C:\\Users\\LEUM_\\Desktop\\Tangle\\Tangle-Offline-website-2023\\app\\page.jsx"]}]
    },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 11977)), "C:\\Users\\LEUM_\\Desktop\\Tangle\\Tangle-Offline-website-2023\\app\\layout.js"],
'head': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 22725)), "C:\\Users\\LEUM_\\Desktop\\Tangle\\Tangle-Offline-website-2023\\app\\head.js"],
        }
      ]
    }.children;
    const pages = ["C:\\Users\\LEUM_\\Desktop\\Tangle\\Tangle-Offline-website-2023\\app\\page.jsx"]

    
    
    

    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
  

/***/ }),

/***/ 8267:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 47877))

/***/ }),

/***/ 91241:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(14353);
module.exports = createProxy("C:\\Users\\LEUM_\\Desktop\\Tangle\\Tangle-Offline-website-2023\\app\\page.jsx");


/***/ }),

/***/ 47877:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Homepage)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(56786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/render/dom/motion.mjs + 144 modules
var motion = __webpack_require__(94945);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(69232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
;// CONCATENATED MODULE: ./app/components/ui/svg/elipse.jsx




const svgVariants = {
    hidden: {
        scale: 0.1,
        opacity: 0,
        blur: "5px"
    },
    visible: {
        scale: 1,
        opacity: 1,
        blur: "0px",
        transition: {
            default: {
                duration: 0.3,
                ease: [
                    0,
                    0.71,
                    0.2,
                    1.01
                ],
                delay: 2
            },
            scale: {
                type: "spring",
                damping: 20,
                stiffness: 600,
                restDelta: 0.05,
                delay: 2
            },
            opacity: {
                delay: 3
            }
        }
    }
};
const pathVariants = {
    hidden: {
        pathLength: 0,
        opacity: 0
    },
    visible: {
        pathLength: 1,
        opacity: 1,
        transition: {
            duration: 1.5,
            ease: "easeInOut",
            delay: 0.5
        }
    }
};
const Ellipse = ({ icon , color  })=>{
    if (icon === "zap") {
        return /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
            variants: svgVariants,
            initial: "hidden",
            animate: "visible",
            className: "self-center w-fit flex p-3",
            height: "60",
            width: "60",
            style: {
                background: `radial-gradient(50% 50% at 50% 50%, ${color} 0%, rgba(0, 173, 228, 0) 100%)`
            },
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.svg */.E.svg, {
                variants: svgVariants,
                initial: "hidden",
                animate: "visible",
                width: "18",
                height: "18",
                viewBox: "0 0 18 20",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                        variants: pathVariants,
                        initial: "hidden",
                        animate: "visible",
                        d: "M10.2435 1.96753L1.91016 11.9675H9.41016L8.57682 18.6342L16.9102 8.6342H9.41016L10.2435 1.96753Z",
                        stroke: "white",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }),
                    "Sorry, your browser does not support inline SVG."
                ]
            })
        });
    } else if (icon === "heart") {
        return /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
            variants: svgVariants,
            initial: "hidden",
            animate: "visible",
            className: "self-center w-fit flex p-3",
            height: "60",
            width: "60",
            style: {
                background: `radial-gradient(50% 50% at 50% 50%, ${color} 0%, rgba(0, 173, 228, 0) 100%)`
            },
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.svg */.E.svg, {
                variants: svgVariants,
                initial: "hidden",
                animate: "visible",
                width: "14",
                height: "14",
                viewBox: "0 0 20 18",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                        variants: pathVariants,
                        d: "M17.3671 2.84172C16.9415 2.41589 16.4361 2.0781 15.8799 1.84763C15.3237 1.61716 14.7275 1.49854 14.1254 1.49854C13.5234 1.49854 12.9272 1.61716 12.371 1.84763C11.8147 2.0781 11.3094 2.41589 10.8838 2.84172L10.0004 3.72506L9.11709 2.84172C8.25735 1.98198 7.09129 1.49898 5.87542 1.49898C4.65956 1.49898 3.4935 1.98198 2.63376 2.84172C1.77401 3.70147 1.29102 4.86753 1.29102 6.08339C1.29102 7.29925 1.77401 8.46531 2.63376 9.32506L3.51709 10.2084L10.0004 16.6917L16.4838 10.2084L17.3671 9.32506C17.7929 8.89943 18.1307 8.39407 18.3612 7.83785C18.5917 7.28164 18.7103 6.68546 18.7103 6.08339C18.7103 5.48132 18.5917 4.88514 18.3612 4.32893C18.1307 3.77271 17.7929 3.26735 17.3671 2.84172V2.84172Z",
                        stroke: "white",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }),
                    "Sorry, your browser does not support inline SVG."
                ]
            })
        });
    } else if (icon === "sad") {
        return /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
            variants: svgVariants,
            initial: "hidden",
            animate: "visible",
            className: "self-center w-fit flex p-3",
            height: "60",
            width: "60",
            style: {
                background: `radial-gradient(50% 50% at 50% 50%, ${color} 0%, rgba(0, 173, 228, 0) 100%)`
            },
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.svg */.E.svg, {
                variants: svgVariants,
                initial: "hidden",
                animate: "visible",
                width: "18",
                height: "18",
                viewBox: "1 0 20 20",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                        clipPath: "url(#clip0_1439_8962)",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                                variants: pathVariants,
                                d: "M10.0001 18.3333C14.6025 18.3333 18.3334 14.6023 18.3334 9.99996C18.3334 5.39759 14.6025 1.66663 10.0001 1.66663C5.39771 1.66663 1.66675 5.39759 1.66675 9.99996C1.66675 14.6023 5.39771 18.3333 10.0001 18.3333Z",
                                stroke: "white",
                                strokeWidth: "2",
                                strokeLinecap: "round",
                                strokeLinejoin: "round"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                                variants: pathVariants,
                                d: "M6.66675 12.5H13.3334",
                                stroke: "white",
                                strokeWidth: "2",
                                strokeLinecap: "round",
                                strokeLinejoin: "round"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                                variants: pathVariants,
                                d: "M7.5 7.5H7.50833",
                                stroke: "white",
                                strokeWidth: "2",
                                strokeLinecap: "round",
                                strokeLinejoin: "round"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                                variants: pathVariants,
                                d: "M12.5 7.5H12.5083",
                                stroke: "white",
                                strokeWidth: "2",
                                strokeLinecap: "round",
                                strokeLinejoin: "round"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                            id: "clip0_1439_8962",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                width: "20",
                                height: "20",
                                fill: "white"
                            })
                        })
                    }),
                    "Sorry, your browser does not support inline SVG."
                ]
            })
        });
    } else if (icon === "happy") {
        return /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
            variants: svgVariants,
            initial: "hidden",
            animate: "visible",
            className: "self-center w-fit flex p-3",
            height: "60",
            width: "60",
            style: {
                background: `radial-gradient(50% 50% at 50% 50%, ${color} 0%, rgba(0, 173, 228, 0) 100%)`
            },
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.svg */.E.svg, {
                variants: svgVariants,
                initial: "hidden",
                animate: "visible",
                width: "18",
                height: "18",
                viewBox: "-1 0 20 20",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                        clipPath: "url(#clip0_1439_8969)",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                                variants: pathVariants,
                                d: "M9.99996 18.3334C14.6023 18.3334 18.3333 14.6025 18.3333 10.0001C18.3333 5.39771 14.6023 1.66675 9.99996 1.66675C5.39759 1.66675 1.66663 5.39771 1.66663 10.0001C1.66663 14.6025 5.39759 18.3334 9.99996 18.3334Z",
                                stroke: "white",
                                strokeWidth: "2",
                                strokeLinecap: "round",
                                strokeLinejoin: "round"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                                variants: pathVariants,
                                d: "M6.66663 11.6667C6.66663 11.6667 7.91663 13.3334 9.99996 13.3334C12.0833 13.3334 13.3333 11.6667 13.3333 11.6667",
                                stroke: "white",
                                strokeWidth: "2",
                                strokeLinecap: "round",
                                strokeLinejoin: "round"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                                variants: pathVariants,
                                d: "M7.5 7.5H7.50833",
                                stroke: "white",
                                strokeWidth: "2",
                                strokeLinecap: "round",
                                strokeLinejoin: "round"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                                variants: pathVariants,
                                d: "M12.5 7.5H12.5083",
                                stroke: "white",
                                strokeWidth: "2",
                                strokeLinecap: "round",
                                strokeLinejoin: "round"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                            id: "clip0_1439_8969",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                width: "20",
                                height: "20",
                                fill: "white"
                            })
                        })
                    }),
                    "Sorry, your browser does not support inline SVG."
                ]
            })
        });
    } else if (icon === "share") {
        return /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
            variants: svgVariants,
            initial: "hidden",
            animate: "visible",
            className: "self-center w-fit flex p-3",
            height: "60",
            width: "60",
            style: {
                background: `radial-gradient(50% 50% at 50% 50%, ${color} 0%, rgba(0, 173, 228, 0) 100%)`
            },
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.svg */.E.svg, {
                variants: svgVariants,
                initial: "hidden",
                animate: "visible",
                width: "18",
                height: "18",
                viewBox: "0 0 20 20",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                        clipPath: "url(#clip0_1439_8976)",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                                variants: pathVariants,
                                d: "M15.1621 6.70264C16.5428 6.70264 17.6621 5.58335 17.6621 4.20264C17.6621 2.82192 16.5428 1.70264 15.1621 1.70264C13.7814 1.70264 12.6621 2.82192 12.6621 4.20264C12.6621 5.58335 13.7814 6.70264 15.1621 6.70264Z",
                                stroke: "white",
                                strokeWidth: "2",
                                strokeLinecap: "round",
                                strokeLinejoin: "round"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                                variants: pathVariants,
                                d: "M5.16211 12.5361C6.54282 12.5361 7.66211 11.4168 7.66211 10.0361C7.66211 8.65542 6.54282 7.53613 5.16211 7.53613C3.7814 7.53613 2.66211 8.65542 2.66211 10.0361C2.66211 11.4168 3.7814 12.5361 5.16211 12.5361Z",
                                stroke: "white",
                                strokeWidth: "2",
                                strokeLinecap: "round",
                                strokeLinejoin: "round"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                                variants: pathVariants,
                                d: "M15.1621 18.3696C16.5428 18.3696 17.6621 17.2503 17.6621 15.8696C17.6621 14.4889 16.5428 13.3696 15.1621 13.3696C13.7814 13.3696 12.6621 14.4889 12.6621 15.8696C12.6621 17.2503 13.7814 18.3696 15.1621 18.3696Z",
                                stroke: "white",
                                strokeWidth: "2",
                                strokeLinecap: "round",
                                strokeLinejoin: "round"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                                variants: pathVariants,
                                d: "M7.32056 11.2944L13.0122 14.6111",
                                stroke: "white",
                                strokeWidth: "2",
                                strokeLinecap: "round",
                                strokeLinejoin: "round"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                                variants: pathVariants,
                                d: "M13.0039 5.46094L7.32056 8.7776",
                                stroke: "white",
                                strokeWidth: "2",
                                strokeLinecap: "round",
                                strokeLinejoin: "round"
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                            id: "clip0_1439_8976",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                                width: "20",
                                height: "20",
                                fill: "white",
                                transform: "translate(0.162109 0.0361328)"
                            })
                        })
                    }),
                    "Sorry, your browser does not support inline SVG."
                ]
            })
        });
    } else {
        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
            height: "60",
            width: "60",
            style: {
                background: `radial-gradient(50% 50% at 50% 50%, ${color} 0%, rgba(0, 173, 228, 0) 100%)`
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("ellipse", {
                    className: "fill-transparent stroke-transparent stroke-1",
                    cx: "100",
                    cy: "100",
                    rx: "100",
                    ry: "100"
                }),
                "Sorry, your browser does not support inline SVG."
            ]
        });
    }
};
Ellipse.propTypes = {
    color: (prop_types_default()).string
};

// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/value/use-scroll.mjs
var use_scroll = __webpack_require__(40162);
;// CONCATENATED MODULE: ./app/components/ui/progress/verticalLine.jsx




function VerticalLine({ color , heigth , width  }) {
    const ref = (0,react_.useRef)(null);
    const { scrollYProgress  } = (0,use_scroll/* useScroll */.v)({
        target: ref,
        offset: [
            "50% 100%",
            "end center"
        ]
    });
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        style: {
            minHeight: heigth,
            maxWidth: width
        },
        className: "max-h-full",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            ref: ref,
            children: /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                style: {
                    filter: `drop-shadow(0px 0px 15px ${color})`,
                    minHeight: heigth,
                    minWidth: width
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                    style: {
                        filter: `drop-shadow(0px 0px 15px ${color})`,
                        minHeight: heigth,
                        minWidth: width
                    },
                    height: "100%",
                    width: "100%",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("line", {
                            x1: "21",
                            y1: "0",
                            x2: "21",
                            y2: heigth,
                            className: "stroke-[2px] opacity-20",
                            stroke: `${color}`
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.line */.E.line, {
                            x1: "21",
                            y1: "0",
                            x2: "21",
                            y2: heigth,
                            className: "stroke-[2px] fill-none",
                            stroke: `${color}`,
                            style: {
                                pathLength: scrollYProgress
                            }
                        })
                    ]
                })
            })
        })
    });
}
VerticalLine.propTypes = {
    color: (prop_types_default()).string,
    heigth: (prop_types_default()).number,
    width: (prop_types_default()).number
};

// EXTERNAL MODULE: ./app/components/ui/animation/wordsAnimation.jsx
var wordsAnimation = __webpack_require__(55644);
;// CONCATENATED MODULE: ./app/components/sections/SectionFour.jsx





function SectionFour({ text  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "px-2 md:px-14 lg:px-32 w-full",
        children: /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
            className: " ",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex gap-12",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "bg- flex justify-center content-center align-middle relative h-[450px]",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "bg- flex justify-center content-center align-middle gap-6",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: " flex h-[63px] ml-0.5 bg-tangle-rich-black-FOGBRA-29 rounded-full px-5 py-10 self-start mt-10",
                                        style: {
                                            background: "radial-gradient(50% 50% at 50% 50%, rgba(13, 17, 28, 1) 85%, rgba(13, 17, 28, 0.6) 100%)"
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Ellipse, {
                                            icon: "sad",
                                            className: "h-16 p-12 my-5 max-w-[30px] ",
                                            color: "rgba(255,0,0,0.4)"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "bg-red- py-5",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex flex-col mt-10 align-middle content-top justify-top pr-10",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                                    className: "max-w-full pt-2",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(wordsAnimation/* default */.Z, {
                                                        className: "text-base sm:text-lg md:text-xl lg:text-2xl font-title",
                                                        text: text.header,
                                                        tag: "h4"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                                    className: "max-w-full md:w-full lg:w-4/5 pr-2 pt-2",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(wordsAnimation/* default */.Z, {
                                                        className: "text-base sm:text-lg md:text-xl lg:text-2xl font-body ",
                                                        text: text.description,
                                                        tag: "p"
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "bg-yellow- flex absolute -z-30 left-5 top-0",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(VerticalLine, {
                                    color: "red",
                                    width: 42,
                                    heigth: 450
                                })
                            })
                        ]
                    })
                })
            })
        })
    });
}

;// CONCATENATED MODULE: ./app/components/ui/progress/horizonatalLine.jsx




function HorizonatalLine({ color , heigth , width  }) {
    const ref = (0,react_.useRef)(null);
    const { scrollYProgress  } = (0,use_scroll/* useScroll */.v)({
        target: ref,
        // offset: ['start end', 'start end']
        offset: [
            "50% 50%",
            "end center"
        ]
    });
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        style: {
            maxHeight: heigth,
            maxWidth: width
        },
        className: "",
        children: /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
            ref: ref,
            children: /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                style: {
                    filter: `drop-shadow(0px 0px 15px ${color})`,
                    minHeight: heigth,
                    minWidth: width
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                    style: {
                        filter: `drop-shadow(0px 0px 15px ${color})`,
                        minHeight: heigth,
                        minWidth: width
                    },
                    height: "100%",
                    width: "100%",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("line", {
                            x1: "0",
                            y1: heigth / 2,
                            x2: width,
                            y2: heigth / 2,
                            className: "stroke-[2px] opacity-20",
                            stroke: `${color}`
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.line */.E.line, {
                            x1: "0",
                            y1: heigth / 2,
                            x2: width,
                            y2: heigth / 2,
                            className: "stroke-[2px] fill-none",
                            stroke: `${color}`,
                            style: {
                                pathLength: scrollYProgress
                            }
                        })
                    ]
                })
            })
        })
    });
}
HorizonatalLine.propTypes = {
    color: (prop_types_default()).string,
    heigth: (prop_types_default()).number,
    width: (prop_types_default()).number
};

// EXTERNAL MODULE: ./app/components/ui/animation/lettersAnimation.jsx
var lettersAnimation = __webpack_require__(11296);
// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/utils/use-in-view.mjs
var use_in_view = __webpack_require__(93978);
;// CONCATENATED MODULE: ./app/components/ui/animation/sectionsAnimation.jsx



function SectionAnimation({ children  }) {
    const ref = (0,react_.useRef)(null);
    const isInView = (0,use_in_view/* useInView */.Y)(ref, {
        once: false
    });
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        ref: ref,
        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
            style: {
                transform: isInView ? "none" : "translateX(-200px)",
                opacity: isInView ? 1 : 0,
                transition: "all 0.9s cubic-bezier(0.17, 0.55, 0.55, 1) 0.5s"
            },
            children: children
        })
    });
}

;// CONCATENATED MODULE: ./app/components/ui/buttons/buttonApps.js

function ButtonApps({ type , text , url  }) {
    if (type === "apple") {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
            className: "bg-tangle-oxford-blue flex px-7 md:px-14 py-3 rounded-lg",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex self-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                        width: "30",
                        height: "34",
                        viewBox: "0 0 30 34",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            d: "M22.375 0.666748C20.4533 0.778415 18.2472 1.84899 16.9355 3.21232C15.7505 4.45232 14.8156 6.29394 15.1973 8.0756C17.2856 8.1306 19.3817 7.03229 20.6367 5.64396C21.8084 4.34563 22.6967 2.53341 22.375 0.666748ZM22.4889 8.07235C19.4739 8.07235 18.2133 9.92456 16.125 9.92456C13.9767 9.92456 12.0128 8.18953 9.41276 8.18953C5.87609 8.1912 0.5 11.4673 0.5 19.1856C0.5 26.2073 6.86276 34.0001 10.4544 34.0001C12.6361 34.0217 13.165 32.6284 16.125 32.6134C19.0883 32.5917 19.7278 34.0184 21.9128 34.0001C24.3728 33.9817 26.2939 31.2785 27.6973 29.1368C28.7039 27.6035 29.1178 26.8207 29.8978 25.0873C24.1095 23.6207 22.9578 14.2862 29.8978 12.3562C28.5878 10.1212 24.7639 8.07235 22.4889 8.07235Z",
                            fill: "#FFFCFA"
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    target: "_self",
                    href: url || "#",
                    rel: "noopener noreferrer",
                    className: "justify-self-center self-center place-content-center pl-4 text-sm ",
                    children: text
                })
            ]
        });
    } else {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
            className: "bg-tangle-oxford-blue flex px-7 md:px-14 py-3 rounded-lg self-start",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex self-center",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                        width: "31",
                        height: "33",
                        viewBox: "0 0 31 33",
                        fill: "none",
                        xmlns: "http://www.w3.org/2000/svg",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            d: "M4.52669 0.880127L17.6615 14.5585L21.5449 10.5155C14.8533 6.73054 6.00336 1.72346 4.52669 0.880127ZM0.734375 1.74601C0.592708 2.07601 0.5 2.4381 0.5 2.83976V31.3196C0.5 31.6479 0.573958 31.951 0.682292 32.2343L15.3503 16.9641L0.734375 1.74601ZM24.5397 12.2115L19.9727 16.9641L24.5039 21.6842C27.2856 20.1092 29.2109 19.0181 29.2109 19.0181C30.0426 18.5131 30.5084 17.7359 30.4967 16.8892C30.4851 16.0642 30.0043 15.3031 29.2077 14.8515C29.0993 14.7898 27.2197 13.7265 24.5397 12.2115ZM17.6615 19.373L4.62435 32.9439C6.86935 31.6673 15.1624 26.9702 21.5091 23.3769L17.6615 19.373Z",
                            fill: "#FFFCFA"
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                    target: "_self",
                    href: url || "#",
                    rel: "noopener noreferrer",
                    className: "justify-self-center self-center place-content-center pl-4 text-sm",
                    children: text
                })
            ]
        });
    }
}
;

;// CONCATENATED MODULE: ./app/components/ui/progress/curveLineWithVertical.jsx




function CurveLineWithVertical({ color  }) {
    const ref = (0,react_.useRef)(null);
    const { scrollYProgress  } = (0,use_scroll/* useScroll */.v)({
        target: ref,
        offset: [
            "50% 100%",
            "end center"
        ]
    });
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "mb-16",
        children: /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
            ref: ref,
            children: /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                style: {
                    filter: `drop-shadow(0px 0px 15px ${color})`
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                    style: {
                        filter: `drop-shadow(0px 0px 15px ${color})`
                    },
                    width: "42",
                    height: "150",
                    fill: "none",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            className: `stroke-[${color}] opacity-20 stroke-[2px]`,
                            d: "M42 20C40 20 21 21 21 41C20 61 21 121.667 21 900",
                            stroke: `${color}`,
                            style: {
                                pathLength: scrollYProgress,
                                filter: `drop-shadow(0px 0px 15px ${color})`
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                            className: `stroke-[${color}] stroke-[2px] fill-none]`,
                            whileInView: {
                                pathLength: scrollYProgress
                            },
                            d: "M42 20C40 20 21 21 21 41C20 61 21 121.667 21 900",
                            stroke: `${color}`,
                            style: {
                                pathLength: scrollYProgress,
                                filter: `drop-shadow(0px 0px 15px ${color})`
                            }
                        })
                    ]
                })
            })
        })
    });
}
CurveLineWithVertical.propTypes = {
    color: (prop_types_default()).string
};

// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/components/AnimatePresence/index.mjs + 2 modules
var AnimatePresence = __webpack_require__(45543);
// EXTERNAL MODULE: ./node_modules/react-tsparticles/cjs/index.js
var cjs = __webpack_require__(2362);
var cjs_default = /*#__PURE__*/__webpack_require__.n(cjs);
// EXTERNAL MODULE: ./node_modules/tsparticles/cjs/index.js
var tsparticles_cjs = __webpack_require__(17750);
;// CONCATENATED MODULE: ./app/components/particles/particlesBackground.js




const ParticlesBackground = ({ id  })=>{
    const particlesInit = (0,react_.useCallback)(async (engine)=>{
        await (0,tsparticles_cjs.loadFull)(engine);
    }, []);
    const particlesLoaded = (0,react_.useCallback)(async (container)=>{
        await console.log(container);
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx((cjs_default()), {
        id: id,
        className: "-z-10 h-full absolute top-0 right-0 w-1/2 ",
        init: particlesInit,
        loaded: particlesLoaded,
        options: {
            background: {
                color: {
                    value: " transparent"
                }
            },
            fullScreen: {
                enable: false
            },
            fpsLimit: 120,
            interactivity: {
                events: {
                    onClick: {
                        enable: false,
                        mode: "push"
                    },
                    onHover: {
                        enable: false,
                        mode: "repulse"
                    },
                    resize: true
                },
                modes: {
                    push: {
                        quantity: 4
                    },
                    repulse: {
                        distance: 200,
                        duration: 0.4
                    }
                }
            },
            life: {
                duration: {
                    sync: true,
                    value: 5
                },
                count: 1
            },
            particles: {
                color: {
                    value: [
                        "#86208B",
                        "#EA1E6D"
                    ]
                },
                links: {
                    color: {
                        value: [
                            "#154078"
                        ]
                    },
                    distance: 150,
                    enable: true,
                    opacity: 0.25,
                    width: 0.5
                },
                collisions: {
                    enable: true
                },
                move: {
                    directions: "none",
                    enable: true,
                    outModes: {
                        default: "bounce"
                    },
                    random: false,
                    speed: 0.6,
                    straight: false
                },
                number: {
                    density: {
                        enable: true,
                        area: 800
                    },
                    value: 160
                },
                opacity: {
                    value: {
                        max: 0.8,
                        min: 0
                    }
                },
                shape: {
                    type: "circle"
                },
                size: {
                    value: {
                        min: 1,
                        max: 5
                    }
                }
            },
            detectRetina: true
        }
    });
};
/* harmony default export */ const particlesBackground = (ParticlesBackground);

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(48421);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./app/components/sections/SectionTwo.jsx









function SectionTwo({ text  }) {
    const [index, setIndex] = (0,react_.useState)(0);
    const currentWord = text.activities[index];
    (0,react_.useEffect)(()=>{
        const i = setInterval(()=>{
            setIndex((i)=>(i + 1) % text.activities.length);
        }, 5000);
        return ()=>{
            clearInterval(i);
        };
    }, [
        text.activities.length
    ]);
    const variants = {
        initial: {
            opacity: 0,
            scale: 0
        },
        enter: {
            opacity: 1,
            scale: 1
        },
        exit: {
            position: "absolute",
            opacity: 0,
            scale: 0
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "relative ",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "px-2 md:px-14 lg:px-32 w-full max-w-full overflow-hidden",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                        className: " ",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "flex gap-12",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "bg- flex justify-center content-center align-middle relative h-[450px]",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "bg- flex justify-center content-center align-middle gap-6",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: " flex h-[63px] ml-0.5 bg-tangle-rich-black-FOGBRA-29 rounded-full px-5 py-10 self-start mt-10",
                                                    style: {
                                                        background: "radial-gradient(50% 50% at 50% 50%, rgba(13, 17, 28, 1) 85%, rgba(13, 17, 28, 0.6) 100%)"
                                                    },
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Ellipse, {
                                                        icon: "heart",
                                                        className: "h-16 p-12 my-5 max-w-[30px]",
                                                        color: "rgba(0, 173, 228, 0.8)"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "bg-red- py-5",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: " mt-5 flex flex-col align-middle justify-start",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                                                className: "pr-5",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx(wordsAnimation/* default */.Z, {
                                                                    className: "text-lg md:text-2xl lg:text-3xl font-title ",
                                                                    text: text.subHeader,
                                                                    tag: "h4"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.div */.E.div, {
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                        className: "flex flex-col",
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                            className: "-mr-8 ",
                                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(lettersAnimation/* default */.Z, {
                                                                                className: "mt-2 mr-2 text-3xl md:text-6xl lg:text-6xl font-bold max-w-full ",
                                                                                text: `${text.header}`,
                                                                                tag: "h3",
                                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                                    className: "text-center inline-block relative self-baseline",
                                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(AnimatePresence/* AnimatePresence */.M, {
                                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.em */.E.em, {
                                                                                            className: " inline-block relative w-[max-content] self-baseline mt-2 mr-2 text-3xl md:text-6xl lg:text-6xl font-bold ",
                                                                                            variants: variants,
                                                                                            initial: "initial",
                                                                                            animate: "enter",
                                                                                            exit: "exit",
                                                                                            transition: {
                                                                                                duration: 3,
                                                                                                type: "spring",
                                                                                                stiffness: 300,
                                                                                                damping: 24
                                                                                            },
                                                                                            children: currentWord || text.activities[0]
                                                                                        })
                                                                                    })
                                                                                })
                                                                            })
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                                        className: "grid grid-cols-2 lg:grid-cols-4 gap-5 lg:gap-20 max-h-[64px] mt-11",
                                                                        children: [
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                className: "self-center",
                                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                                    src: "/logos/merchantLogo4.png",
                                                                                    alt: "Logo The Amsterdam Dungeon",
                                                                                    width: 181,
                                                                                    height: 38,
                                                                                    className: "max-w-full max-h-full m-auto"
                                                                                })
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                className: "self-center",
                                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                                    src: "/logos/merchantLogo1.png",
                                                                                    alt: "Logo Merlin",
                                                                                    width: 57,
                                                                                    height: 45,
                                                                                    className: "max-w-full max-h-full m-auto"
                                                                                })
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                className: "self-center",
                                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                                    src: "/logos/merchantLogo2.png",
                                                                                    alt: "Logo Madame Tussauds",
                                                                                    width: 175,
                                                                                    height: 32,
                                                                                    className: "max-w-full max-h-full m-auto"
                                                                                })
                                                                            }),
                                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                                className: "self-center",
                                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                                                    src: "/logos/merchantLogo3.png",
                                                                                    alt: "Logo Paradiso",
                                                                                    width: 97,
                                                                                    height: 19,
                                                                                    className: "max-w-full max-h-full m-auto"
                                                                                })
                                                                            })
                                                                        ]
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "bg-yellow- flex absolute -z-30 left-5 top-0",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(VerticalLine, {
                                                width: 42,
                                                heigth: 450,
                                                color: "rgba(0,173,228,0.8)"
                                            })
                                        })
                                    ]
                                })
                            })
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(particlesBackground, {
                    id: "particles"
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./app/components/sections/sectionOne.jsx









function SectionOne({ text  }) {
    const titleVariants = {
        hidden: {
            scale: 0.1,
            opacity: 0,
            blur: "5px"
        },
        visible: {
            scale: 1,
            opacity: 1,
            blur: "0px",
            transition: {
                // delayChildren: 0.2,
                staggerChildren: 3,
                staggerDirection: 1
            }
        }
    };
    const fadeInAnimation = {
        hidden: {
            opacity: 0,
            blur: "5px"
        },
        visible: {
            opacity: 1,
            blur: "0px",
            transition: {
                // delayChildren: 0.2,
                staggerChildren: 1,
                staggerDirection: 1
            }
        }
    };
    const fadeInAnimationLong = {
        hidden: {
            opacity: 0,
            blur: "5px"
        },
        visible: {
            opacity: 1,
            blur: "0px",
            transition: {
                // delayChildren: 0.2,
                staggerChildren: 5,
                staggerDirection: 1
            }
        }
    };
    const child = {
        hidden: {
            opacity: 0,
            x: 20,
            transition: {
                type: "spring",
                damping: 12,
                stiffness: 100
            }
        },
        visible: {
            opacity: 1,
            x: 0,
            transition: {
                type: "spring",
                damping: 12,
                stiffness: 100
            }
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.div */.E.div, {
        variants: fadeInAnimationLong,
        initial: "hidden",
        animate: "visible",
        className: "grid grid-cols-1 w-full ",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.div */.E.div, {
                variants: fadeInAnimation,
                className: "z-40 pt-[36rem] md:pt[42rem] lg:pt-96 bg-no-repeat lg:bg-right bg-center bg-cover bg-hero-mobile lg:bg-hero-desktop ",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.div */.E.div, {
                        variants: titleVariants,
                        initial: "hidden",
                        animate: "visible",
                        className: "w-full ",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.div */.E.div, {
                                variants: fadeInAnimation,
                                className: " px-14 md:px-24 lg:px-40 max-w-full",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(lettersAnimation/* default */.Z, {
                                            className: "text-4xl md:text-6xl lg:text-7xl font-titleMain",
                                            text: text[0].header,
                                            tag: "h1"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                        className: "w-4/5 md:w-3/4 lg:w-1/2 mt-5 mb-12",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(wordsAnimation/* default */.Z, {
                                            className: "font-normal text-base md:text-2xl lg:text-3xl font-body",
                                            text: text[0].subHeader,
                                            tag: "p"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                variants: fadeInAnimation,
                                className: "flex flex-row align-top items-start ",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.div */.E.div, {
                                    variants: fadeInAnimation,
                                    className: "relative mt-10 z-50 px-7 md:px-[4.75rem] lg:px-[9.25rem] max-w-full",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.div */.E.div, {
                                            variants: child,
                                            className: " flex ml-12 -mb-12 gap-4 align-top items-start absolute -top-6 z-10 ",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(ButtonApps, {
                                                    type: "apple",
                                                    text: text[0].appleStore,
                                                    url: text[0].appleStoreUrl
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(ButtonApps, {
                                                    text: text[0].playStore,
                                                    url: text[0].playStoreUrl
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.div */.E.div, {
                                            variants: fadeInAnimation,
                                            className: "flex",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                                    className: "max-w-[42px] h-[150px]",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(CurveLineWithVertical, {
                                                        color: "rgba(0,173,228,0.8)"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                                    className: "-mt-[1px]",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(HorizonatalLine, {
                                                        heigth: 42,
                                                        width: 250,
                                                        color: "rgba(0,173,228,0.8)"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                        variants: fadeInAnimation,
                        className: "-mt-96 h-96 bg-gradient-to-b from-transparent to-tangle-rich-black-FOGBRA-29"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(SectionAnimation, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(SectionTwo, {
                    text: text[1]
                })
            })
        ]
    });
}

;// CONCATENATED MODULE: ./app/components/video-player/VideoPlayer.jsx

function VideoPlayer({ text  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "mx-2 md:mx-14 lg:mx-32 aspect-video rounded-3xl overflow-hidden flex",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: " max-full aspect-video",
            children: /*#__PURE__*/ jsx_runtime_.jsx("iframe", {
                className: "aspect-video",
                width: "100%",
                height: "100%",
                src: "https://www.youtube.com/embed/PXO5Uig6qg8",
                title: text.tittle,
                allow: "accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",
                allowFullScreen: true
            })
        })
    });
}

;// CONCATENATED MODULE: ./app/components/sections/SectionThree.jsx


function SectionThree({ text  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(VideoPlayer, {
            text: text
        })
    });
}

;// CONCATENATED MODULE: ./app/components/ui/progress/curveLine.jsx




function CurveLine({ color , heigth , width  }) {
    const ref = (0,react_.useRef)(null);
    const { scrollYProgress  } = (0,use_scroll/* useScroll */.v)({
        target: ref,
        offset: [
            "50% 50%",
            "end center"
        ]
    });
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "",
        children: /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
            ref: ref,
            children: /*#__PURE__*/ jsx_runtime_.jsx("figure", {
                style: {
                    filter: `drop-shadow(0px 0px 15px ${color})`
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                    style: {
                        filter: `drop-shadow(0px 0px 15px ${color})`,
                        minHeight: heigth,
                        minWidth: width
                    },
                    width: "42",
                    height: "42",
                    fill: "none",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("path", {
                            className: `stroke-[${color}] opacity-20 stroke-[2px]`,
                            d: "M21,42c0-11.6-9.4-21-21-21",
                            stroke: `${color}`,
                            style: {
                                pathLength: scrollYProgress,
                                filter: `drop-shadow(0px 0px 15px ${color})`
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                            className: `stroke-[${color}] stroke-[2px] fill-none]`,
                            whileInView: {
                                pathLength: scrollYProgress
                            },
                            d: "M21,42c0-11.6-9.4-21-21-21",
                            stroke: `${color}`,
                            style: {
                                pathLength: scrollYProgress,
                                filter: `drop-shadow(0px 0px 15px ${color})`
                            }
                        })
                    ]
                })
            })
        })
    });
}
CurveLine.propTypes = {
    color: (prop_types_default()).string,
    heigth: (prop_types_default()).number,
    width: (prop_types_default()).number
};

;// CONCATENATED MODULE: ./app/components/sections/SectionFive.jsx






function SectionFive({ text  }) {
    const ref = (0,react_.useRef)(null);
    const isInView = (0,use_in_view/* useInView */.Y)(ref, {
        once: false
    });
    const container = {
        hidden: {
            opacity: 0
        },
        visible: (i = 1)=>({
                opacity: 1,
                transition: {
                    staggerChildren: 0.25,
                    delayChildren: 0.50 * i
                }
            })
    };
    const child = {
        visible: {
            opacity: 1,
            x: 0,
            y: 0,
            transition: {
                type: "spring",
                damping: 20,
                stiffness: 400
            }
        },
        hidden: {
            opacity: 0,
            x: -20,
            y: 10,
            transition: {
                type: "spring",
                damping: 20,
                stiffness: 400
            }
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "grid grid-cols-1 relative max-w-full",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex w-full flex-col max-w-full",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex pl-5 max-w-full relative mx-2 md:mx-14 lg:mx-32",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "-rotate-180 h-[42px]",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(CurveLine, {
                                color: "red",
                                heigth: 42,
                                width: 42
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-1/2 max-w-full h-[42px] overflow-hidden",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(HorizonatalLine, {
                                heigth: 42,
                                width: 3000,
                                color: "red"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-1/2 max-w-full h-[42px] overflow-hidden -rotate-180",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(HorizonatalLine, {
                                heigth: 42,
                                width: 3000,
                                color: "red"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "mr-5 ",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "mr-48 md:mr-0 lg:mr-0",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(CurveLine, {
                                        color: "red",
                                        heigth: 42,
                                        width: 42
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: " md:max-h-60 overflow-hidden",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(VerticalLine, {
                                            color: "red",
                                            heigth: 625,
                                            width: 42
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex flex-col w-full items-center align-middle absolute top-0 -mt-28 px-5",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.div */.E.div, {
                        className: "grid grid-cols-1 h-48 md:grid-cols-3 gap-y-5 gap-x-4 lg:gap-6 max-w-4xl",
                        variants: container,
                        initial: "hidden",
                        animate: isInView ? "visible" : "hidden",
                        ref: ref,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                className: "gird grid-cols-1 shadow h-full bg-tangle-oxford-blue rounded-lg px-5 py-10 my-5",
                                variants: child,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-col align-middle content-center justify-center h-full",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: "text-center font-bold text-[#D90026] text-4xl lg:text-5xl mb-3",
                                            children: text.headerCardOne
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-center",
                                            children: text.descriptionCardOne
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                className: "gird grid-cols-1 shadow h-full bg-tangle-oxford-blue rounded-lg px-5 py-10 my-5",
                                variants: child,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-col align-middle content-center justify-center h-full",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: "text-center font-bold text-[#D90026] text-4xl lg:text-5xl mb-3",
                                            children: text.headerCardTwo
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-center",
                                            children: text.descriptionCardTwo
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                className: "gird grid-cols-1 shadow h-full bg-tangle-oxford-blue rounded-lg px-5 py-10 my-5",
                                variants: child,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-col align-middle content-center justify-center h-full",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: "text-center font-bold text-[#D90026] text-4xl lg:text-5xl mb-3",
                                            children: text.headerCardThree
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "text-center",
                                            children: text.descriptionCardThree
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./app/components/sections/SectionSix.jsx


function SectionSix({ text  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "h-screen w-full flex flex-col align-middle justify-center content-center",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "h-full flex flex-col align-middle justify-center content-center bg-black",
            children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                className: "bg-black text-center",
                children: text.tv
            })
        })
    });
}

// EXTERNAL MODULE: ./node_modules/framer-motion/dist/es/value/use-spring.mjs + 2 modules
var use_spring = __webpack_require__(74291);
;// CONCATENATED MODULE: ./app/components/cards/hook/Hooks.jsx

const useParentSize = ()=>{
    const parentRef = (0,react_.useRef)(null);
    const [width, setWidth] = (0,react_.useState)(0);
    (0,react_.useLayoutEffect)(()=>{
        const handlSetWidth = ()=>{
            if (parentRef.current) {
                setWidth(parentRef.current.offsetWidth);
            }
        };
        function handleResize() {
            handlSetWidth();
        }
        window.addEventListener("resize", handleResize);
        handlSetWidth();
    }, []);
    return [
        parentRef,
        width
    ];
};

;// CONCATENATED MODULE: ./app/components/cards/Tile/Tile.jsx


const Tile = /*#__PURE__*/ (0,react_.forwardRef)(({ children , perspective =false , dark =false , perspectiveDist =400 , className  }, ref)=>{
    const wrapperRef = (0,react_.useRef)();
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        ref: wrapperRef,
        className: `relative pt-[100%] overflow-hidden rounded-lg outline-none ${className}`,
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "absolute top-0 right-0 left-0 bottom-0",
            ref: ref,
            style: {
                background: dark ? "hsla(0, 0%, 13%, 1)" : "transparent",
                perspective: perspective ? `${perspectiveDist * 2}px` : "none",
                touchAction: "none"
            },
            children: children
        })
    });
});
Tile.displayName = "Tile";

// EXTERNAL MODULE: ./app/data/images.json
var data_images = __webpack_require__(28144);
;// CONCATENATED MODULE: ./app/components/cards/ComplexCards.jsx






//  Create some data where each item
//  in the array will represent an unique card
// const data = ['a', 'b', 'c', 'd', 'e', 'f', 'g']
const data = data_images/* cards */._u;
// Mapping function to create duplicates with UIDs
const mapData = (data, prefix)=>data.map((item, i)=>({
            id: `${prefix}${i}`,
            content: item
        }));
// Array we are going to work with
const dataClone = [
    // First 3 duplicates are going to be rendered:
    // One is for exit animations
    ...mapData(data, "1"),
    // Second one is being displayed on screen
    ...mapData(data, "2"),
    // Third one is for inital aniamtion
    ...mapData(data, "3"),
    // Last one is to avoid cards animation
    // from the final position to the initial one
    ...mapData(data, "4")
];
// ************************************************** //
// *                                                * //
// *       https://twitter.com/wojciech_dobry       * //
// *      for more interaction design content,      * //
// *         just hit the follow button  :)         * //
// *                                                * //
// ************************************************** //
// ************************************************** //
// *                                                * //
// *        This code is more of a prototype.       * //
// *   T'd optimize if before using in production   * //
// *                                                * //
// ************************************************** //
function ComplexCards({ desktop , tablet , mobile , className  }) {
    // I like to work with relative sizes, rather than px
    // useParentSize gets parent size, so I can
    // size everything relatively to the container.
    // You can work with pixels if you like
    const [ref, size] = useParentSize();
    const [state, setState] = (0,react_.useState)({
        current: 0,
        arr: dataClone
    });
    // A function to rotate the array by n steps
    // (btw. This could be a signle loop)
    // I just find it easier to read
    const rotateArray = (0,react_.useCallback)((n = 1)=>{
        const newArr = [
            ...state.arr
        ];
        if (n > 0) {
            for(let i = 0; i < n; i++){
                const first = newArr.shift();
                newArr.push(first);
            }
            setState({
                current: n,
                arr: newArr
            });
        } else {
            for(let i1 = 0; i1 < -n; i1++){
                const last = newArr.pop();
                newArr.unshift(last);
            }
            setState({
                current: n,
                arr: newArr
            });
        }
    }, [
        state.arr
    ]);
    (0,react_.useEffect)(()=>{
        const interval = setInterval(()=>{
            rotateArray();
        }, 3000);
        return ()=>clearInterval(interval);
    }, [
        rotateArray
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(Tile, {
        ref: ref,
        perspective: true,
        perspectiveDist: size * 90,
        className: className,
        children: state.arr.map((item, i)=>// Render only first 3 copies of data.
            // The fourth copy should be out of render,
            // otherwise cards will also animate
            // from last to first position
            i < data.length * 3 && /*#__PURE__*/ jsx_runtime_.jsx(Card, {
                i: i,
                current: state.current,
                name: item.content,
                rotateArray: rotateArray,
                length: data.length,
                size: size,
                style: state.style,
                desktop: desktop,
                tablet: tablet,
                mobile: mobile
            }, item.id))
    });
}
// Spring configuration
const spring = {
    type: "spring",
    damping: 70,
    stiffness: 600,
    restDelta: 0.0001,
    restSpeed: 0.0001
};
const Card = ({ i , name , length , size , rotateArray , current , desktop , tablet , mobile  })=>{
    // Card is sized relatively to the container,
    // just to maintain all ratios.
    const cardWidth = size * 0.35 * 1 * (mobile ? 1.15 : 1);
    const cardHeight = size * 0.55 * 1 * (mobile ? 1.15 : 1);
    // Bunch of helpers
    // to get the correct array slice
    const { isLeft , isFirst , isCenter , isRight  } = {
        isLeft: i < length,
        isFirst: i === length,
        isCenter: i > length && i <= length * 2 - 1,
        isRight: i > length * 2 - 1 && i < length * 3
    };
    // Another helper to start counting
    // from the "first visible" card
    const iFromFirst = i - length;
    // I usually work with hsl() model
    // bgLightness defines the l component of the background
    const bgLightness = 13;
    // I don't want any card to be darker
    // than the background itself
    const clampLightness = (value)=>Math.max(value, bgLightness);
    // Helpers, helpers, helpers...
    const lightnessHSL = (value)=>`hsl(0,0%,${clampLightness(value)}%)`;
    const offsetCalc = (start, step)=>start * size + step * i;
    const backgroundCalc = (start, step)=>lightnessHSL(start + step * iFromFirst);
    // Actual styles for each card set.
    // I want to have control over:
    // – first card (the draggable one)
    // – center (visible cards)
    // – left (out of container but matters for exit animation)
    // – right (out of container but matters for initial animation)
    let styles = {};
    if (desktop) {
        styles = {
            [isLeft]: {
                posX: offsetCalc(-1.25, 0),
                posY: offsetCalc(-0.25, 0),
                posZ: offsetCalc(0, 1),
                rotX: 0,
                rotY: 45,
                rotZ: -90,
                background: backgroundCalc(95, 0)
            },
            [isFirst]: {
                posX: offsetCalc(-0.25, -cardWidth / 6 / i),
                posY: offsetCalc(-0.4, 2.5),
                posZ: offsetCalc(-1, i * i * -0.1),
                rotX: 0,
                rotY: 0,
                rotZ: 0,
                background: backgroundCalc(95, 0)
            },
            [isCenter]: {
                posX: offsetCalc(i * 0.20, -i * 1 - 0.67 * cardWidth),
                posY: offsetCalc(-0.4, 2),
                posZ: offsetCalc(-1, i * i * -0.1),
                rotX: i * 1,
                rotY: i * 1,
                rotZ: 30 + i * -4.3,
                background: backgroundCalc(100, -25)
            },
            [isRight]: {
                posX: offsetCalc(-1.5, 0),
                posY: offsetCalc(0.25, 0),
                posZ: offsetCalc(-0.25, -20),
                rotX: 0,
                rotY: 0,
                rotZ: 0,
                background: backgroundCalc(0, 0)
            }
        };
    }
    if (tablet) {
        styles = {
            [isLeft]: {
                posX: offsetCalc(-1.25, 0),
                posY: offsetCalc(-0.25, 0),
                posZ: offsetCalc(0, 1),
                rotX: 0,
                rotY: 45,
                rotZ: -90,
                background: backgroundCalc(95, 0)
            },
            [isFirst]: {
                posX: offsetCalc(0.12, -cardWidth / 6 / i),
                posY: offsetCalc(-0.4, 2.5),
                posZ: offsetCalc(-1, i * i * -0.1),
                rotX: 0,
                rotY: 0,
                rotZ: 2,
                background: backgroundCalc(95, 0)
            },
            [isCenter]: {
                posX: offsetCalc(i * 0.205, -i * 5.5 - 0.45 * cardWidth),
                posY: offsetCalc(-0.4, 2),
                posZ: offsetCalc(-1, i * i * -0.1),
                rotX: i * 1,
                rotY: i * 1,
                rotZ: 30 + i * -3.3,
                background: backgroundCalc(100, -25)
            },
            [isRight]: {
                posX: offsetCalc(-1.5, 0),
                posY: offsetCalc(0.25, 0),
                posZ: offsetCalc(-0.25, -20),
                rotX: 0,
                rotY: 0,
                rotZ: 0,
                background: backgroundCalc(0, 0)
            }
        };
    }
    if (mobile) {
        styles = {
            [isLeft]: {
                posX: offsetCalc(-1.25, 0),
                posY: offsetCalc(-0.25, 0),
                posZ: offsetCalc(0, 1),
                rotX: 0,
                rotY: 45,
                rotZ: -90,
                background: backgroundCalc(95, 0)
            },
            [isFirst]: {
                posX: offsetCalc(-0.105, -cardWidth / 10 / i),
                posY: offsetCalc(-0.45, 4),
                posZ: offsetCalc(-1, i * i * -0.1),
                rotX: 0,
                rotY: 0,
                rotZ: 2,
                background: backgroundCalc(95, 0)
            },
            [isCenter]: {
                posX: offsetCalc(i * 0.205, -i * 1.1 - 0.52 * cardWidth),
                posY: offsetCalc(-0.45, 4),
                posZ: offsetCalc(-1, i * i * -0.1),
                rotX: i * 1,
                rotY: i * 1,
                rotZ: 2,
                background: backgroundCalc(100, -25)
            },
            [isRight]: {
                posX: offsetCalc(-1.5, 0),
                posY: offsetCalc(0.25, 0),
                posZ: offsetCalc(-0.25, -20),
                rotX: 0,
                rotY: 0,
                rotZ: 0,
                background: backgroundCalc(0, 0)
            }
        };
    }
    // All cards are styled based on their index:
    const { posX , posY , posZ , background , rotX , rotY , rotZ  } = styles[isLeft || isRight || isCenter || isFirst];
    // Springs for drag animation
    const dPosX = (0,use_spring/* useSpring */.q)(posX, spring);
    const dPosY = (0,use_spring/* useSpring */.q)(posY, spring);
    const dPosZ = (0,use_spring/* useSpring */.q)(posZ, spring);
    const dRotX = (0,use_spring/* useSpring */.q)(rotX, spring);
    const dRotY = (0,use_spring/* useSpring */.q)(rotY, spring);
    const dRotZ = (0,use_spring/* useSpring */.q)(rotZ, spring);
    // This function controlls the drag behavior
    // and constrains verical and horizontal drag force
    const setXY = (info, consX, consY)=>{
        dPosX.set(posX + info.offset.x * size * consX / 1000);
        dPosY.set(posY + info.offset.y * size * consY / 1000);
        dRotX.set(rotX + info.offset.y / size * 120000 * consY / 1000);
        dRotY.set(rotY + info.offset.x / size * -120000 * consY / 1000);
        dRotZ.set(rotZ + info.offset.x / size * 120000 * consY / 1000);
    };
    const handlePanEnd = (info)=>{
        const minVelocity = Math.abs(info.velocity.x) > 80;
        const minDistance = Math.abs(info.offset.x) > size / 48;
        const direction = info.offset.x > 0 ? -1 : 1;
        if (minDistance && minVelocity && isFirst) {
            rotateArray(direction);
            setXY(info, 0, 0);
        } else {
            setXY(info, 0, 0);
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
        onTap: ()=>{
            rotateArray(i - length);
        },
        onPan: (_, info)=>{
            isFirst ? setXY(info, 0.8, 0.35) : setXY(info, 0.15, 0.15);
        },
        onPanEnd: (_, info)=>{
            handlePanEnd(info);
        },
        whileHover: {
            scale: 1.1
        },
        transition: spring,
        animate: {
            x: posX,
            y: posY,
            z: posZ,
            rotateX: rotX,
            rotateY: rotY,
            rotateZ: rotZ,
            background,
            transition: {
                delay: (iFromFirst + current) * 0.025
            }
        },
        style: {
            position: "absolute",
            x: dPosX,
            y: dPosY,
            z: dPosZ,
            rotateX: dRotX,
            rotateY: dRotY,
            rotateZ: dRotZ,
            width: `${cardWidth}px`,
            height: `${cardHeight}px`,
            top: "50%",
            left: "50%",
            zIndex: length - i,
            borderRadius: `${size * 0.035}px`,
            userSelect: "none",
            overflow: "hidden",
            cursor: isFirst ? "grab" : "pointer",
            touchAction: "auto",
            backgroundColor: "#0C101C"
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "w-full h-full bg-cover bg-no-repeat bg-tangle-oxford-blue",
            style: {
                backgroundImage: `url(${name})`
            }
        })
    });
};

;// CONCATENATED MODULE: ./app/components/sections/SectionSeven.jsx








function SectionSeven({ text  }) {
    const [matches, setMatches] = (0,react_.useState)(false);
    (0,react_.useEffect)(()=>{
        const mediaQuery = window.matchMedia("(min-width: 1024px)");
        const handleMediaQueryChange = (event)=>{
            setMatches(event.matches);
        };
        mediaQuery.addEventListener("change", handleMediaQueryChange);
        return ()=>{
            mediaQuery.removeEventListener("change", handleMediaQueryChange);
        };
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "px-2 md:px-14 lg:px-32 w-full",
        children: /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
            className: " ",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "gap-12 ",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "bg- w-fit flex justify-end content-end align-middle relative md:h-[1100px] lg:h-[800px] bg-green- ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " absolute top-0 left-0 w-[62%] hidden lg:grid ",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "grid grid-cols-1 gap-3 grid-flow-row-dense box-border w-full max-w-full absolute top-0 lg:-mx-32 h-[700px] overflow-hidden",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ComplexCards, {
                                        desktop: true
                                    })
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "bg-blue- flex justify-center content-center align-middle gap-6 lg:max-w-[68%] z-30",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "bg-red- py-5 bg-red- z-30 flex flex-col",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex flex-col mt-10 align-middle content-top justify-top",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                                    className: "max-w-full pt-2",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(wordsAnimation/* default */.Z, {
                                                        className: "text-base sm:text-lg md:text-xl lg:text-2xl font-title text-end",
                                                        text: text.subHeader,
                                                        tag: "h4"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                                    className: "max-w-full self-end",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(lettersAnimation/* default */.Z, {
                                                        className: "py-2 text-3xl md:text-6xl lg:text-6xl font-bold text-end ",
                                                        text: text.header,
                                                        tag: "h3"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                                    className: "max-w-full pl-10 bg-yellow- self-end",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(wordsAnimation/* default */.Z, {
                                                        className: "text-base sm:text-lg md:text-xl lg:text-2xl font-body text-end",
                                                        text: text.description,
                                                        tag: "p"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: " ",
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        className: "grid lg:hidden grid-cols-1 gap-3 grid-flow-row-dense box-border md:-mx-14 h-[700px] overflow-hidden",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx(ComplexCards, {
                                                                tablet: true,
                                                                className: "hidden md:grid lg:hidden"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx(ComplexCards, {
                                                                mobile: true,
                                                                className: "md:hidden"
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: " flex h-[63px] mr-0.5 bg-tangle-rich-black-FOGBRA-29 rounded-full px-5 py-10 mt-10",
                                        style: {
                                            background: "radial-gradient(50% 50% at 50% 50%, rgba(13, 17, 28, 1) 85%, rgba(13, 17, 28, 0.6) 100%)"
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Ellipse, {
                                            icon: "happy",
                                            className: "h-16 p-12 my-5 max-w-[30px] ",
                                            color: "rgb(1, 209, 46, 0.4)"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "bg-yellow- absolute -z-30 right-5 top-0 overflow-hidden max-h-full",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(VerticalLine, {
                                    color: "rgb(1, 209, 46)",
                                    width: 42,
                                    heigth: matches ? 800 : 1100
                                })
                            })
                        ]
                    })
                })
            })
        })
    });
}

;// CONCATENATED MODULE: ./app/components/ui/svg/Icon.jsx




const Icon_svgVariants = {
    hidden: {
        scale: 0.1,
        opacity: 0,
        blur: "5px"
    },
    visible: {
        scale: 1,
        opacity: 1,
        blur: "0px",
        transition: {
            default: {
                duration: 0.3,
                ease: [
                    0,
                    0.71,
                    0.2,
                    1.01
                ],
                delay: 2
            },
            scale: {
                type: "spring",
                damping: 20,
                stiffness: 600,
                restDelta: 0.05,
                delay: 2
            },
            opacity: {
                delay: 3
            }
        }
    }
};
const Icon_pathVariants = {
    hidden: {
        pathLength: 0,
        opacity: 0
    },
    visible: {
        pathLength: 1,
        opacity: 1,
        transition: {
            duration: 1.5,
            ease: "easeInOut",
            delay: 0.5
        }
    }
};
const Icon = ({ icon , color  })=>{
    if (icon === "sun") {
        return /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
            variants: Icon_svgVariants,
            initial: "hidden",
            animate: "visible",
            className: "self-center w-fit flex p-3",
            height: "60",
            width: "60",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.svg */.E.svg, {
                variants: Icon_svgVariants,
                initial: "hidden",
                animate: "visible",
                width: "51",
                height: "55",
                viewBox: "0 0 51 55",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                        variants: Icon_pathVariants,
                        d: "M36.3333 27.5001C36.3333 24.6269 35.1919 21.8714 33.1603 19.8398C31.1286 17.8081 28.3731 16.6667 25.5 16.6667C22.6268 16.6667 19.8713 17.8081 17.8396 19.8398C15.808 21.8714 14.6666 24.6269 14.6666 27.5001",
                        stroke: "#01E132",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                        variants: Icon_pathVariants,
                        d: "M25.5 8L25.5 1.5",
                        stroke: "#01E132",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                        variants: Icon_pathVariants,
                        d: "M8.64478 10.6433L11.7214 13.72",
                        stroke: "#01E132",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                        variants: Icon_pathVariants,
                        d: "M1.66663 27.5H5.99996",
                        stroke: "#01E132",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                        variants: Icon_pathVariants,
                        d: "M45 27.5H49.3333",
                        stroke: "#01E132",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                        variants: Icon_pathVariants,
                        d: "M39.2786 13.72L42.3552 10.6433",
                        stroke: "#01E132",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                        variants: Icon_pathVariants,
                        d: "M14.6666 27.4999C14.6666 30.3731 15.808 33.1286 17.8396 35.1602C19.8712 37.1919 22.6267 38.3333 25.4999 38.3333C28.3731 38.3333 31.1286 37.1919 33.1602 35.1602C35.1919 33.1286 36.3333 30.3731 36.3333 27.4999",
                        stroke: "#01E132",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                        variants: Icon_pathVariants,
                        d: "M25.5 47L25.5 53.5",
                        stroke: "#01E132",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                        variants: Icon_pathVariants,
                        d: "M42.3551 44.3567L39.2784 41.28",
                        stroke: "#01E132",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                        variants: Icon_pathVariants,
                        d: "M49.3333 27.5H44.9999",
                        stroke: "#01E132",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                        variants: Icon_pathVariants,
                        d: "M6 27.5H1.66667",
                        stroke: "#01E132",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                        variants: Icon_pathVariants,
                        d: "M11.7213 41.28L8.64465 44.3567",
                        stroke: "#01E132",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    })
                ]
            })
        });
    } else if (icon === "search") {
        return /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
            variants: Icon_svgVariants,
            initial: "hidden",
            animate: "visible",
            className: "self-center w-fit flex p-3",
            height: "60",
            width: "60",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.svg */.E.svg, {
                variants: Icon_svgVariants,
                initial: "hidden",
                animate: "visible",
                width: "53",
                height: "53",
                viewBox: "0 0 53 53",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                        variants: Icon_pathVariants,
                        d: "M24.2917 41.9583C34.0487 41.9583 41.9583 34.0487 41.9583 24.2917C41.9583 14.5346 34.0487 6.625 24.2917 6.625C14.5346 6.625 6.625 14.5346 6.625 24.2917C6.625 34.0487 14.5346 41.9583 24.2917 41.9583Z",
                        stroke: "#00E432",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                        variants: Icon_pathVariants,
                        d: "M46.375 46.375L36.7688 36.7688",
                        stroke: "#00E432",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    })
                ]
            })
        });
    } else if (icon === "map") {
        return /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
            variants: Icon_svgVariants,
            initial: "hidden",
            animate: "visible",
            className: "self-center w-fit flex p-3",
            height: "60",
            width: "60",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.svg */.E.svg, {
                variants: Icon_svgVariants,
                width: "53",
                height: "53",
                viewBox: "0 0 53 53",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                        variants: Icon_pathVariants,
                        d: "M2.66663 13.4999V48.1666L17.8333 39.4999L35.1666 48.1666L50.3333 39.4999V4.83325L35.1666 13.4999L17.8333 4.83325L2.66663 13.4999Z",
                        stroke: "#01D12E",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                        variants: Icon_pathVariants,
                        d: "M17.8334 4.83325V39.4999",
                        stroke: "#01D12E",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.path */.E.path, {
                        variants: Icon_pathVariants,
                        d: "M35.1666 13.5V48.1667",
                        stroke: "#01D12E",
                        strokeWidth: "2",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                    })
                ]
            })
        });
    } else {
        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
            height: "60",
            width: "60",
            style: {
                background: `radial-gradient(50% 50% at 50% 50%, ${color} 0%, rgba(0, 173, 228, 0) 100%)`
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
                    className: "fill-transparent stroke-transparent stroke-1",
                    cx: "100",
                    cy: "100",
                    rx: "100",
                    ry: "100"
                }),
                "Sorry, your browser does not support inline SVG."
            ]
        });
    }
};
Icon.propTypes = {
    color: (prop_types_default()).string
};

;// CONCATENATED MODULE: ./app/components/sections/SectionEight.jsx







const container = {
    hidden: {
        opacity: 0
    },
    visible: (i = 1)=>({
            opacity: 1,
            transition: {
                staggerChildren: 0.25,
                delayChildren: 0.75 * i,
                staggerDirection: -1
            }
        })
};
const child = {
    visible: {
        opacity: 1,
        x: 0,
        y: 0,
        transition: {
            type: "spring",
            damping: 20,
            stiffness: 400
        }
    },
    hidden: {
        opacity: 0,
        x: -20,
        y: 10,
        transition: {
            type: "spring",
            damping: 20,
            stiffness: 400
        }
    }
};
function SectionEight({ text  }) {
    const ref = (0,react_.useRef)(null);
    const isInView = (0,use_in_view/* useInView */.Y)(ref, {
        once: false
    });
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "grid grid-cols-1 relative max-w-full z-50",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "flex w-full flex-col max-w-full",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex px-5 max-w-full relative mx-2 md:mx-14 lg:mx-32 ",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "ml-48 md:ml-0 lg:ml-0 ",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "-scale-x-100",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(CurveLine, {
                                        color: "rgb(1, 209, 46)",
                                        heigth: 42,
                                        width: 42
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "md:max-h-60 overflow-hidden",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(VerticalLine, {
                                        color: "rgb(1, 209, 46)",
                                        heigth: 625,
                                        width: 42
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-1/2 max-w-full h-[42px] overflow-hidden",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(HorizonatalLine, {
                                color: "rgb(1, 209, 46)",
                                heigth: 42,
                                width: 3000
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-1/2 max-w-full h-[42px] overflow-hidden -rotate-180 ",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(HorizonatalLine, {
                                color: "rgb(1, 209, 46)",
                                heigth: 42,
                                width: 3000
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: " h-[42px] -rotate-180 -scale-x-100",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(CurveLine, {
                                color: "rgb(1, 209, 46)",
                                heigth: 42,
                                width: 42
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex flex-col w-full items-center align-middle absolute top-0 -mt-28 px-5",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.div */.E.div, {
                        className: "grid grid-cols-1 h-48 md:grid-cols-3 gap-y-5 gap-x-4 lg:gap-6 max-w-4xl",
                        variants: container,
                        initial: "hidden",
                        animate: isInView ? "visible" : "hidden",
                        ref: ref,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                className: "gird grid-cols-1 shadow h-full bg-tangle-oxford-blue rounded-lg px-5 py-10 my-5",
                                variants: child,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-col align-middle content-center justify-center h-full",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: " flex h-[63px] m-auto rounded-full ",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
                                                icon: "sun",
                                                className: "h-16 p-12 my-5 max-w-[30px] ",
                                                color: "rgb(1, 209, 46)"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: "text-center font-bold text-white text-xl lg:text-2xl mb-3",
                                            children: text.headerCardOne
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                className: "gird grid-cols-1 shadow h-full bg-tangle-oxford-blue rounded-lg px-5 py-10 my-5",
                                variants: child,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-col align-middle content-center justify-center h-full",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: " flex h-[63px] m-auto rounded-full ",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
                                                icon: "search",
                                                className: "h-16 p-12 my-5 max-w-[30px] ",
                                                color: "rgb(1, 209, 46)"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: "text-center font-bold text-white text-xl lg:text-2xl mb-3",
                                            children: text.headerCardTwo
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                className: "gird grid-cols-1 shadow h-full bg-tangle-oxford-blue rounded-lg px-5 py-10 my-5",
                                variants: child,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-col align-middle content-center justify-center h-full",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: " flex h-[63px] m-auto rounded-full ",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Icon, {
                                                icon: "map",
                                                className: "h-16 p-12 my-5 max-w-[30px] ",
                                                color: "rgb(1, 209, 46)"
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h3", {
                                            className: "text-center font-bold text-white text-xl lg:text-2xl mb-3",
                                            children: [
                                                text.headerCardThree,
                                                " "
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./app/components/particles/startsBackground.jsx




const StarsBackground = ({ id  })=>{
    const particlesInit = (0,react_.useCallback)(async (engine)=>{
        // you can initiate the tsParticles instance (engine) here, adding custom shapes or presets
        // this loads the tsparticles package bundle, it's the easiest method for getting everything ready
        // starting from v2 you can add only the features you need reducing the bundle size
        await (0,tsparticles_cjs.loadFull)(engine);
    }, []);
    const particlesLoaded = (0,react_.useCallback)(async (container)=>{
        await console.log(container);
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx((cjs_default()), {
        className: "-z-10 h-full absolute top-0 right-0 w-full",
        id: id,
        init: particlesInit,
        loaded: particlesLoaded,
        options: {
            background: {
                color: {
                    value: "transparent"
                }
            },
            fullScreen: {
                enable: false
            },
            fpsLimit: 60,
            interactivity: {
                events: {
                    onClick: {
                        enable: false,
                        mode: "push"
                    },
                    onHover: {
                        enable: false,
                        mode: "repulse"
                    },
                    resize: true
                },
                modes: {
                    push: {
                        quantity: 4
                    },
                    repulse: {
                        distance: 200,
                        duration: 0.4
                    }
                }
            },
            particles: {
                twinkle: {
                    enable: true,
                    frequency: 50,
                    opacity: 0.5
                },
                life: {
                    duration: {
                        sync: false,
                        value: 5
                    }
                },
                color: {
                    value: [
                        "#FFFFFF"
                    ]
                },
                links: {
                    color: {
                        value: [
                            "#FFFFFF"
                        ]
                    },
                    distance: 50,
                    enable: false,
                    opacity: 0.25,
                    width: 0.5
                },
                collisions: {
                    enable: false
                },
                move: {
                    directions: "top",
                    enable: true,
                    speed: 0.009
                },
                number: {
                    density: {
                        enable: true,
                        area: 9000
                    },
                    value: 200
                },
                opacity: {
                    value: {
                        max: 0.8,
                        min: 0
                    }
                },
                shape: {
                    type: "star"
                },
                size: {
                    value: {
                        min: 0.5,
                        max: 1
                    }
                }
            },
            detectRetina: true
        }
    });
};
/* harmony default export */ const startsBackground = (StarsBackground);

;// CONCATENATED MODULE: ./app/components/sections/SectionNine.jsx




function SectionNine({ text  }) {
    const [images, setImages] = (0,react_.useState)(data_images/* waves */.lH);
    const containerRef = (0,react_.useRef)(null);
    const [dimensions, setDimensions] = (0,react_.useState)({
        width: 0,
        height: 0
    });
    const [showCard, setShowCard] = (0,react_.useState)(true);
    (0,react_.useEffect)(()=>{
        const handleResize = ()=>{
            setDimensions({
                width: containerRef.current.offsetWidth,
                height: containerRef.current.offsetHeight
            });
        };
        handleResize();
        window.addEventListener("resize", handleResize);
        setImages(images.map((image)=>{
            return {
                image,
                x: Math.floor(Math.random() * dimensions.width) / 2,
                y: Math.floor(Math.random() * dimensions.height) / 2
            };
        }));
        return ()=>{
            window.removeEventListener("resize", handleResize);
        };
    }, []);
    const centerImage = images[0];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: " h-[682px] md:[416px] lg:h-[600px] px-2 md:px-14 lg:px-32 w-full flex flex-col align-middle justify-center content-center ",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                ref: containerRef,
                className: "h-full bg-tangle-rich-black-FOGBRA-29 relative overflow-hidden bg-no-repeat bg-center bg-cover bg-img-map",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "h-full w-full flex justify-center content-center items-center absolute top-0 left-0",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.svg */.E.svg, {
                            width: "137",
                            height: "137",
                            viewBox: "0 0 137 137",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            initial: {
                                scale: 0.1,
                                rotate: "0deg",
                                transition: {
                                    duration: 5
                                },
                                opacity: 1
                            },
                            animate: {
                                scale: [
                                    0.1,
                                    1,
                                    4
                                ],
                                rotate: "360deg",
                                transition: {
                                    duration: 7.5,
                                    repeat: Infinity,
                                    repeatDelay: 0.5
                                },
                                opacity: [
                                    1,
                                    1,
                                    1,
                                    0.5,
                                    0
                                ]
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    d: "M135 68.5C135 59.7671 133.28 51.1197 129.938 43.0516C126.596 34.9834 121.698 27.6525 115.523 21.4774C109.348 15.3023 102.017 10.404 93.9485 7.06201C85.8803 3.72008 77.2329 2 68.5 2C59.7671 2 51.1197 3.72007 43.0516 7.06201C34.9834 10.4039 27.6525 15.3023 21.4774 21.4774C15.3023 27.6525 10.404 34.9834 7.06201 43.0515C3.72007 51.1197 2 59.7671 2 68.5C2 77.2329 3.72007 85.8803 7.06201 93.9484C10.4039 102.017 15.3023 109.348 21.4774 115.523C27.6525 121.698 34.9834 126.596 43.0515 129.938C51.1197 133.28 59.7671 135 68.5 135C77.2329 135 85.8803 133.28 93.9484 129.938C102.017 126.596 109.348 121.698 115.523 115.523C121.698 109.348 126.596 102.017 129.938 93.9484C133.28 85.8803 135 77.2329 135 68.5L135 68.5Z",
                                    stroke: "url(#paint0_angular_1439_9085)",
                                    strokeWidth: "2",
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeDasharray: "1 15"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("radialGradient", {
                                        id: "paint0_angular_1439_9085",
                                        cx: "0",
                                        cy: "0",
                                        r: "1",
                                        gradientUnits: "userSpaceOnUse",
                                        gradientTransform: "translate(38.5697 48.6514) rotate(36.001) scale(106.476)",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                                offset: "4.7067e-07",
                                                stopColor: "#5C7DD6"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                                offset: "0.474664",
                                                stopColor: "#BB62D1",
                                                stopOpacity: "0.05"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                                offset: "1",
                                                stopColor: "#D957AC",
                                                stopOpacity: "0.55"
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "h-full w-full flex justify-center content-center items-center absolute top-0 left-0",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.svg */.E.svg, {
                            width: "248",
                            height: "248",
                            viewBox: "0 0 248 248",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            initial: {
                                scale: 0.1,
                                rotate: "0deg",
                                transition: {
                                    duration: 5
                                },
                                opacity: 1
                            },
                            animate: {
                                scale: [
                                    0.1,
                                    1,
                                    4
                                ],
                                rotate: "360deg",
                                transition: {
                                    duration: 7.5,
                                    repeat: Infinity,
                                    repeatDelay: 0.5
                                },
                                opacity: [
                                    1,
                                    1,
                                    1,
                                    0.5,
                                    0
                                ]
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    d: "M2 124C1.99999 140.021 5.15561 155.886 11.2867 170.687C17.4178 185.489 26.4042 198.938 37.7329 210.267C49.0617 221.596 62.5109 230.582 77.3126 236.713C92.1143 242.844 107.979 246 124 246C140.021 246 155.886 242.844 170.687 236.713C185.489 230.582 198.938 221.596 210.267 210.267C221.596 198.938 230.582 185.489 236.713 170.687C242.844 155.886 246 140.021 246 124C246 107.979 242.844 92.1144 236.713 77.3126C230.582 62.5109 221.596 49.0617 210.267 37.733C198.938 26.4042 185.489 17.4178 170.687 11.2867C155.886 5.15563 140.021 2.00001 124 2C107.979 2 92.1144 5.15562 77.3126 11.2867C62.5109 17.4178 49.0617 26.4042 37.733 37.733C26.4042 49.0617 17.4178 62.5109 11.2867 77.3126C5.15562 92.1143 2 107.979 2 124L2 124Z",
                                    stroke: "url(#paint0_angular_1439_9086)",
                                    strokeWidth: "2",
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeDasharray: "1 15"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("radialGradient", {
                                        id: "paint0_angular_1439_9086",
                                        cx: "0",
                                        cy: "0",
                                        r: "1",
                                        gradientUnits: "userSpaceOnUse",
                                        gradientTransform: "translate(179.291 160.667) rotate(-143.999) scale(196.695 196.695)",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                                offset: "4.7067e-07",
                                                stopColor: "#5C7DD6"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                                offset: "0.474664",
                                                stopColor: "#BB62D1",
                                                stopOpacity: "0.05"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                                offset: "1",
                                                stopColor: "#D957AC",
                                                stopOpacity: "0.55"
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "h-full w-full flex justify-center content-center items-center absolute top-0 left-0",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.svg */.E.svg, {
                            width: "368",
                            height: "367",
                            viewBox: "0 0 368 367",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            initial: {
                                scale: 0.1,
                                rotate: "0deg",
                                transition: {
                                    duration: 5
                                },
                                opacity: 1
                            },
                            animate: {
                                scale: [
                                    0.1,
                                    1,
                                    4
                                ],
                                rotate: "360deg",
                                transition: {
                                    duration: 7.5,
                                    repeat: Infinity,
                                    repeatDelay: 0.5
                                },
                                opacity: [
                                    1,
                                    1,
                                    1,
                                    0.5,
                                    0
                                ]
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    d: "M366 183.5C366 159.665 361.292 136.063 352.146 114.042C342.999 92.0213 329.593 72.0129 312.692 55.1592C295.792 38.3055 275.729 24.9365 253.648 15.8155C231.566 6.69449 207.9 2 184 2C160.1 2 136.434 6.69448 114.353 15.8155C92.2715 24.9365 72.2079 38.3054 55.3076 55.1591C38.4072 72.0128 25.0009 92.0212 15.8543 114.042C6.70772 136.063 2 159.665 2 183.5C2 207.335 6.70772 230.937 15.8543 252.958C25.0009 274.979 38.4071 294.987 55.3075 311.841C72.2079 328.695 92.2715 342.063 114.353 351.185C136.434 360.306 160.1 365 184 365C207.9 365 231.566 360.306 253.647 351.185C275.729 342.064 295.792 328.695 312.692 311.841C329.593 294.987 342.999 274.979 352.146 252.958C361.292 230.937 366 207.335 366 183.5L366 183.5Z",
                                    stroke: "url(#paint0_angular_1439_9087)",
                                    strokeWidth: "2",
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeDasharray: "1 15"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("radialGradient", {
                                        id: "paint0_angular_1439_9087",
                                        cx: "0",
                                        cy: "0",
                                        r: "1",
                                        gradientUnits: "userSpaceOnUse",
                                        gradientTransform: "translate(101.292 128.803) rotate(35.9256) scale(293.95 293.697)",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                                offset: "4.7067e-07",
                                                stopColor: "#5C7DD6"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                                offset: "0.474664",
                                                stopColor: "#BB62D1",
                                                stopOpacity: "0.05"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                                offset: "1",
                                                stopColor: "#D957AC",
                                                stopOpacity: "0.55"
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "h-full w-full flex justify-center content-center items-center absolute top-0 left-0",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.svg */.E.svg, {
                            width: "500",
                            height: "500",
                            viewBox: "0 0 500 500",
                            fill: "none",
                            xmlns: "http://www.w3.org/2000/svg",
                            initial: {
                                scale: 0.1,
                                rotate: "0deg",
                                transition: {
                                    duration: 5
                                },
                                opacity: 1
                            },
                            animate: {
                                scale: [
                                    0.1,
                                    1,
                                    4
                                ],
                                rotate: "360deg",
                                transition: {
                                    duration: 7.5,
                                    repeat: Infinity,
                                    repeatDelay: 0.5
                                },
                                opacity: [
                                    1,
                                    1,
                                    1,
                                    0.5,
                                    0
                                ]
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                    d: "M250 2C217.432 2 185.183 8.4147 155.095 20.8779C125.006 33.341 97.6665 51.6086 74.6376 74.6375C51.6086 97.6664 33.3411 125.006 20.8779 155.094C8.41472 185.183 2.00001 217.432 2 250C2 282.568 8.4147 314.817 20.8779 344.905C33.341 374.994 51.6086 402.334 74.6375 425.362C97.6664 448.391 125.006 466.659 155.094 479.122C185.183 491.585 217.432 498 250 498C282.568 498 314.817 491.585 344.905 479.122C374.994 466.659 402.334 448.391 425.362 425.362C448.391 402.334 466.659 374.994 479.122 344.906C491.585 314.817 498 282.568 498 250C498 217.432 491.585 185.183 479.122 155.095C466.659 125.006 448.391 97.6665 425.362 74.6375C402.334 51.6086 374.994 33.341 344.905 20.8779C314.817 8.41471 282.568 2 250 2L250 2Z",
                                    stroke: "url(#paint0_angular_1439_9088)",
                                    strokeWidth: "2",
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    strokeDasharray: "1 15"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("radialGradient", {
                                        id: "paint0_angular_1439_9088",
                                        cx: "0",
                                        cy: "0",
                                        r: "1",
                                        gradientUnits: "userSpaceOnUse",
                                        gradientTransform: "translate(175.151 362.867) rotate(-53.999) scale(401.519)",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                                offset: "4.7067e-07",
                                                stopColor: "#5C7DD6"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                                offset: "0.474664",
                                                stopColor: "#BB62D1",
                                                stopOpacity: "0.05"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("stop", {
                                                offset: "1",
                                                stopColor: "#D957AC",
                                                stopOpacity: "0.55"
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(FaceImage, {
                        src: centerImage.image,
                        boxWidth: dimensions.width,
                        boxHeigth: dimensions.height,
                        setShowCard: setShowCard,
                        showCard: showCard
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(FaceImage, {
                        src: images[1].image,
                        boxWidth: dimensions.width,
                        boxHeigth: dimensions.height,
                        moveX: 550,
                        moveY: -500,
                        setShowCard: setShowCard,
                        showCard: showCard
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(FaceImage, {
                        src: images[2].image,
                        boxWidth: dimensions.width,
                        boxHeigth: dimensions.height,
                        moveX: 150,
                        moveY: -50,
                        setShowCard: setShowCard,
                        showCard: showCard
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(FaceImage, {
                        src: images[3].image,
                        boxWidth: dimensions.width,
                        boxHeigth: dimensions.height,
                        moveX: -150,
                        moveY: 150,
                        setShowCard: setShowCard,
                        showCard: showCard
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(FaceImage, {
                        src: images[4].image,
                        boxWidth: dimensions.width,
                        boxHeigth: dimensions.height,
                        moveX: 350,
                        moveY: 200,
                        setShowCard: setShowCard,
                        showCard: showCard
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(FaceImage, {
                        src: images[5].image,
                        boxWidth: dimensions.width,
                        boxHeigth: dimensions.height,
                        moveX: -700,
                        moveY: -300,
                        setShowCard: setShowCard,
                        showCard: showCard
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(FaceImage, {
                        src: images[6].image,
                        boxWidth: dimensions.width,
                        boxHeigth: dimensions.height,
                        moveX: -550,
                        moveY: 150,
                        setShowCard: setShowCard,
                        showCard: showCard
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(FaceImage, {
                        src: images[7].image,
                        boxWidth: dimensions.width,
                        boxHeigth: dimensions.height,
                        moveX: -600,
                        moveY: 300,
                        setShowCard: setShowCard,
                        showCard: showCard
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(FaceImage, {
                        src: images[8].image,
                        boxWidth: dimensions.width,
                        boxHeigth: dimensions.height,
                        moveX: 350,
                        moveY: -350,
                        setShowCard: setShowCard,
                        showCard: showCard
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(FaceImage, {
                        src: images[9].image,
                        boxWidth: dimensions.width,
                        boxHeigth: dimensions.height,
                        moveX: -50,
                        moveY: -450,
                        setShowCard: setShowCard,
                        showCard: showCard
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(FaceImage, {
                        src: images[10].image,
                        boxWidth: dimensions.width,
                        boxHeigth: dimensions.height,
                        moveX: 50,
                        moveY: 450,
                        setShowCard: setShowCard,
                        showCard: showCard
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-full relative",
                children: showCard && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "shadow-lg h-[258px] w-[315px] absolute -top-32 right-[7%] z-10 bg-no-repeat bg-center bg-cover bg-activity-basket"
                })
            })
        ]
    });
}
function FaceImage({ src , boxWidth , boxHeigth , moveX , moveY , setShowCard , showCard  }) {
    moveX = moveX || 0;
    moveY = moveY || 0;
    return /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.img */.E.img, {
        src: src,
        alt: "imagen alternativa",
        onClick: ()=>setShowCard(!showCard),
        width: 50,
        height: 50,
        whileHover: {
            scale: 1.5,
            transition: {
                duration: 0.5
            }
        },
        whileTap: {
            scale: 1.25,
            transition: {
                duration: 0.1
            }
        },
        className: "cursor-pointer",
        style: {
            position: "absolute",
            left: `${(boxWidth - 50 + moveX) / 2}px`,
            top: `${(boxHeigth - 50 + moveY) / 2}px`
        }
    });
}

;// CONCATENATED MODULE: ./app/components/sections/SectionTen.jsx






function SectionTen({ text  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "px-2 md:px-14 lg:px-32 w-full",
        children: /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
            className: " ",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex gap-12",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "bg-red- flex justify-center content-center align-middle relative h-[600px]",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "bg-fuchsia- flex justify-center content-center align-middle gap-6",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "bg-green- py-5 flex flex-col mt-10 align-bottom content-bottom mb-12 pr-10 self-end relative",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "flex align-bottom content-bottom self-end gap-6",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                className: "flex h-[63px] ml-0.5 bg-tangle-rich-black-FOGBRA-29 rounded-full px-5 py-10 self-start mt-10",
                                                style: {
                                                    background: "radial-gradient(50% 50% at 50% 50%, rgba(13, 17, 28, 1) 85%, rgba(13, 17, 28, 0.6) 100%)"
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(Ellipse, {
                                                    icon: "share",
                                                    className: "h-16 p-12 my-5 max-w-[30px] ",
                                                    color: "rgba(1, 209, 46, 0.4)"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex flex-col align-bottom content-bottom pr-10 self-end",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                                        className: "max-w-full pt-2 ml-",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(wordsAnimation/* default */.Z, {
                                                            className: "text-base sm:text-lg md:text-xl lg:text-2xl font-title",
                                                            text: text.subHeader,
                                                            tag: "h4"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                                        className: "max-w-full",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(lettersAnimation/* default */.Z, {
                                                            className: "py-2 text-3xl md:text-6xl lg:text-6xl font-bold",
                                                            text: text.header,
                                                            tag: "h3"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                                        className: "max-w-full md:w-full lg:w-4/5 pr-2 pt-2",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(wordsAnimation/* default */.Z, {
                                                            className: "text-base sm:text-lg md:text-xl lg:text-2xl font-body ",
                                                            text: text.description,
                                                            tag: "p"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "bg-yellow- flex absolute -z-30 left-5 top-0",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(VerticalLine, {
                                    color: "rgb(1, 209, 46)",
                                    width: 42,
                                    heigth: 600
                                })
                            })
                        ]
                    })
                })
            })
        })
    });
}

;// CONCATENATED MODULE: ./app/components/ui/carrousel/Carrousel.js




const variants = {
    enter: (direction)=>{
        return {
            x: direction > 0 ? 1000 : -1000,
            opacity: 0,
            zindex: 0
        };
    },
    center: {
        zindex: 1,
        x: 0,
        opacity: 1
    },
    exit: (direction)=>{
        return {
            zindex: 0,
            x: direction < 0 ? 1000 : -1000,
            opacity: 0
        };
    }
};
const initialIndex = 0;
function Carrousel({ numbers , bullets , arrows , className , immagesArray  }) {
    const [page, setPage] = (0,react_.useState)(initialIndex);
    const images = immagesArray;
    const paginationBullets = bullets || false;
    const paginationNumbers = numbers || false;
    const paginationArrows = arrows || false;
    const handleClickAfter = ()=>{
        if (page >= images.length - 1) {
            setPage(initialIndex);
        } else {
            setPage((prevCount)=>prevCount + 1);
        }
    };
    const handleClickBefore = ()=>{
        if (page <= 0) {
            setPage(images.length - 1);
        } else {
            setPage((prevCount)=>prevCount - 1);
        }
    };
    (0,react_.useEffect)(()=>{
        const interval = setInterval(()=>{
            handleClickAfter();
        }, 3000);
        return ()=>clearInterval(interval);
    }, [
        page
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `${className}`,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "overflow-hidden rounded-3xl shadow relative flex w-full min-h-[300px] justify-center items-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(AnimatePresence/* AnimatePresence */.M, {
                        initial: false,
                        custom: page,
                        children: images.map((image, index)=>{
                            const isCurrent = index === page;
                            const direction = index - page;
                            return /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.img */.E.img, {
                                className: "absolute h-full w-full object-cover",
                                src: image,
                                custom: direction,
                                variants: variants,
                                initial: !isCurrent ? "enter" : "center",
                                animate: isCurrent ? "center" : "exit",
                                exit: "exit",
                                transition: {
                                    x: {
                                        type: "spring",
                                        stiffness: 300,
                                        damping: 30
                                    },
                                    opacity: {
                                        duration: 0.2
                                    }
                                },
                                drag: "x",
                                dragConstraints: {
                                    left: 0,
                                    right: 0
                                },
                                dragElastic: 1,
                                onDragEnd: (e, { offset , velocity  })=>{
                                    if (offset.x > 50) {
                                        handleClickBefore();
                                    } else if (offset.x < -50) {
                                        handleClickAfter();
                                    }
                                }
                            }, index);
                        })
                    }),
                    paginationArrows && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "justify-center items-center select-none cursor-pointer flex font-bold z-50 w-10 h-10 text-lg rounded-full absolute right-3 top-1/2 ",
                                onClick: handleClickAfter,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    className: "w-full h-full m-3",
                                    viewBox: "0 0 6.52 11.15",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        d: "m.43.43l5.43,4.69c.3.26.3.72,0,.98L.43,10.71",
                                        stroke: "#01ADE4",
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: "0.86px",
                                        fill: "none"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "justify-center items-center select-none cursor-pointer flex font-bold z-50 w-10 h-10 text-lg rounded-full absolute left-3 top-1/2 -scale-100",
                                onClick: handleClickBefore,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    className: "w-full h-full m-3",
                                    viewBox: "0 0 6.52 11.15",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        d: "m.43.43l5.43,4.69c.3.26.3.72,0,.98L.43,10.71",
                                        stroke: "#01ADE4",
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: "0.86px",
                                        fill: "none"
                                    })
                                })
                            })
                        ]
                    })
                ]
            }),
            paginationBullets && /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex content-center justify-center w-full my-2",
                    children: images.map((image, index)=>{
                        const isCurrent = index === page;
                        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: `bullet w-2 h-2 rounded-full bg-tangle-oxford-blue mx-2 my-0 cursor-pointer ${isCurrent ? "bg-tangle-cyan-process" : ""}`,
                            onClick: ()=>setPage(index)
                        }, index);
                    })
                })
            }),
            paginationNumbers && /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex content-center justify-center w-full",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "mr-2",
                            children: page + 1
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "",
                            children: "/ "
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "ml-2",
                            children: images.length
                        })
                    ]
                })
            })
        ]
    });
}
Carrousel.propTypes = {
    heigth: (prop_types_default()).string
};

;// CONCATENATED MODULE: ./app/components/sections/SectionEleven.jsx





function SectionEleven({ text  }) {
    const ref = (0,react_.useRef)(null);
    const isInView = (0,use_in_view/* useInView */.Y)(ref, {
        once: false
    });
    const container = {
        hidden: {
            opacity: 0
        },
        visible: (i = 1)=>({
                opacity: 1,
                transition: {
                    staggerChildren: 0.25,
                    delayChildren: 0.001 * i
                }
            })
    };
    const child = {
        visible: {
            opacity: 1,
            x: 0,
            y: 0,
            transition: {
                type: "spring",
                damping: 50,
                stiffness: 100
            }
        },
        hidden: {
            opacity: -1,
            x: -20,
            y: 10,
            transition: {
                type: "spring",
                damping: 50,
                stiffness: 100
            }
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.div */.E.div, {
                className: "h-screen px-2 md:px-14 lg:px-32 w-full hidden md:grid grid-cols-4 grid-rows-4 align-middle justify-center content-center gap-5",
                variants: container,
                initial: "hidden",
                animate: isInView ? "visible" : "hidden",
                ref: ref,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                        className: "h-full w-full row-span-1 col-span-2 rounded-2xl bg-no-repeat bg-center bg-cover bg-collage-1",
                        variants: child
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                        className: "h-full w-full rounded-2xl bg-no-repeat bg-center bg-cover bg-collage-2 row-span-1",
                        variants: child
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                        className: "h-full w-full rounded-2xl bg-no-repeat bg-center bg-cover bg-collage-3 row-span-2 col-span-1",
                        variants: child
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                        className: "h-full w-full rounded-2xl bg-no-repeat bg-center bg-cover bg-collage-4 col-span-3 row-span-2",
                        variants: child
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                        className: "h-full w-full rounded-2xl bg-no-repeat bg-center bg-cover bg-collage-5 row-span-1 col-span-1",
                        variants: child
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                        className: "h-full w-full rounded-2xl bg-no-repeat bg-center bg-cover bg-collage-6 row-span-1 col-span-2",
                        variants: child
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                        className: "h-full w-full rounded-2xl bg-no-repeat bg-center bg-cover bg-collage-7 row-span-1 col-span-2",
                        variants: child
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Carrousel, {
                bullets: true,
                className: "lg:hidden md:hidden xl:hidden -mb-6 mx-5",
                immagesArray: data_images/* carrousel */.nu
            })
        ]
    });
}

;// CONCATENATED MODULE: ./app/components/sections/SectionTwelve.jsx






function SectionTwelve({ text  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "px-2 md:px-14 lg:px-32 w-full",
        children: /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
            className: " ",
            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex gap-12",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "bg- flex justify-center content-center align-middle relative h-[230] lg:h-[325px] overflow-hidden",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "bg- flex justify-center content-center align-middle gap-6",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: " flex h-[63px] ml-0.5 bg-tangle-rich-black-FOGBRA-29 rounded-full px-5 py-10 self-start mt-10",
                                        style: {
                                            background: "radial-gradient(50% 50% at 50% 50%, rgba(13, 17, 28, 1) 85%, rgba(13, 17, 28, 0.6) 100%)"
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Ellipse, {
                                            icon: "zap",
                                            className: "h-16 p-12 my-5 max-w-[30px]",
                                            color: "rgba(0, 173, 228, 0.8)"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: " py-5",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex flex-col mt-10 align-middle content-top justify-top pr-10",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                                    className: "max-w-full pt-2",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(wordsAnimation/* default */.Z, {
                                                        className: "text-base sm:text-lg md:text-xl lg:text-2xl font-title",
                                                        text: text.subHeader,
                                                        tag: "h4"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                                    className: "max-w-full",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(lettersAnimation/* default */.Z, {
                                                        className: "py-2 text-3xl md:text-6xl lg:text-6xl font-bold ",
                                                        text: text.header,
                                                        tag: "h3"
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "bg-yellow- flex absolute -z-30 left-5 top-0",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(VerticalLine, {
                                    width: 42,
                                    heigth: 325,
                                    color: "rgba(0,173,228,0.8)"
                                })
                            })
                        ]
                    })
                })
            })
        })
    });
}

;// CONCATENATED MODULE: ./app/components/sections/SectionThirteen.jsx






function SectionThirteen({ text  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: " px-2 md:px-14 lg:px-32 w-full flex flex-col align-middle justify-center content-center ",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "h-full grid grid-cols-1 gap-y-12 lg:grid-cols-2 align-middle justify-center content-center bg-tangle-oxford-blue p-8 md:p-10 lg:p-16 rounded-2xl",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "m-auto lg:pr-16 order-2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                    className: "max-w-full mb-10",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(lettersAnimation/* default */.Z, {
                                        className: "text-3xl md:text-4xl lg:text-5xl font-bold text-[#00ADE4] ",
                                        text: text.header,
                                        tag: "h3"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.div */.E.div, {
                                    className: "max-w-full mb-7 md:mb-8 lg:mb-20",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(wordsAnimation/* default */.Z, {
                                        className: "text-base sm:text-lg md:text-xl lg:text-2xl font-body",
                                        text: text.description,
                                        tag: "p"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: text.button_url,
                                    className: "self-center",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.button */.E.button, {
                                        className: "bg-[#0086D3] rounded-full w-full py-3",
                                        children: text.button
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "m-auto lg:pl-16 h-[165px] md:h-[372px] lg:h-[400px] w-full order-1 lg:order-2",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "h-full rounded-2xl w-full bg-no-repeat bg-center bg-cover bg-img-coffe"
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "flex px-5 max-w-full relative mx-2 md:mx-14 lg:mx-32",
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "max-h-28 md:max-h-52 overflow-hidden",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(VerticalLine, {
                        heigth: 625,
                        width: 42,
                        color: "rgba(0,173,228,0.8)"
                    })
                })
            })
        ]
    });
}

// EXTERNAL MODULE: ./app/components/sections/SectionFifteen.css
var SectionFifteen = __webpack_require__(32438);
;// CONCATENATED MODULE: ./app/components/waves/Waves.jsx



function Waves() {
    const ref = (0,react_.useRef)();
    const importedImages = data_images/* waves */.lH;
    (0,react_.useEffect)(()=>{
        const images = [].slice.call(document.getElementsByClassName("animated-path"));
        let i = 0;
        for (const image of images){
            image.counter = 0 + i;
            i += 0.125;
            if (images.indexOf(image) === images.length / 2) {
                i = 0;
            }
        }
        function moveStar() {
            for (const image of images){
                if (parseInt(image.counter, 10) === 1) {
                    image.counter = 0;
                }
                image.counter += 0.001;
                const straightLength = ref.current.getTotalLength();
                image.setAttribute("transform", "translate(" + (ref.current.getPointAtLength(image.counter * straightLength).x - 15) + "," + (ref.current.getPointAtLength(image.counter * straightLength).y - 9) + "), scale(0.5)");
                if (window.innerWidth >= 768) {
                    image.setAttribute("transform", "translate(" + (ref.current.getPointAtLength(image.counter * straightLength).x - 15) + "," + (ref.current.getPointAtLength(image.counter * straightLength).y - 9) + "), scale(0.5)");
                } else {
                    image.setAttribute("transform", "translate(" + (ref.current.getPointAtLength(image.counter * straightLength).x - 15) + "," + (ref.current.getPointAtLength(image.counter * straightLength).y - 18) + "), scale(1)");
                }
            }
            requestAnimationFrame(moveStar);
        }
        requestAnimationFrame(moveStar);
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        id: "path",
        className: "h-0 w-full absolute left-0 bottom-24 pb-[13%]",
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "h-0 w-full p-0",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                viewBox: "-200 -25 430 500",
                preserveAspectRatio: "xMidYMin slice",
                x: "0",
                y: "15",
                className: "absolute h-full w-full left-0 top-0",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        ref: ref,
                        fill: "none",
                        d: "M -360 0 L -241 0 C -37 -32 32 32 245 -1 L 386 0",
                        width: "100%",
                        stroke: "#0089cf",
                        strokeWidth: "0.03rem"
                    }),
                    importedImages.map((e, i)=>{
                        return /*#__PURE__*/ jsx_runtime_.jsx("image", {
                            className: "animated-path w-10 h-10",
                            href: e
                        }, i);
                    })
                ]
            })
        })
    });
}

// EXTERNAL MODULE: ./app/components/forms/CountrySelector.jsx
var CountrySelector = __webpack_require__(34144);
;// CONCATENATED MODULE: ./app/components/sections/SectionFifteen.jsx






function SectionFifteen_SectionFifteen({ text  }) {
    const [index, setIndex] = (0,react_.useState)(0);
    const currentWord = text.cities[index];
    (0,react_.useEffect)(()=>{
        const i = setInterval(()=>{
            setIndex((i)=>(i + 1) % text.cities.length);
        }, 5000);
        return ()=>{
            clearInterval(i);
        };
    }, [
        text.cities.length
    ]);
    const variants = {
        initial: {
            opacity: 0,
            scale: 0
        },
        enter: {
            opacity: 1,
            scale: 1
        },
        exit: {
            position: "absolute",
            opacity: 0,
            scale: 0
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "px-2 md:px-14 lg:px-32 w-full relative",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: " flex flex-col align-middle content-center justify-center pb-64 pt-24 md:pb-72 md:pt-32 lg:pb-80 lg:pt-36",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "items-center align-middle content-center justify-center flex",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "header-invite text-black text-5xl md:text-7xl lg:text-8xl text-center font-bold inline-block relative self-baseline",
                        children: [
                            text.header,
                            " ",
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            /*#__PURE__*/ jsx_runtime_.jsx(AnimatePresence/* AnimatePresence */.M, {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(motion/* motion.span */.E.span, {
                                    className: "invite-place text-6xl md:text-8xl lg:text-9xl font-bold inline-block relative w-[max-content] self-baseline ",
                                    variants: variants,
                                    initial: "initial",
                                    animate: "enter",
                                    exit: "exit",
                                    transition: {
                                        duration: 3,
                                        type: "spring",
                                        stiffness: 300,
                                        damping: 24
                                    },
                                    children: [
                                        currentWord,
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "text-6xl md:text-8xl lg:text-9xl text-black header-invite self-baseline",
                                            children: "?"
                                        })
                                    ]
                                }, currentWord)
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "invite-text text-lg md:text-2xl mt-12 mb-6 text-center font-semibold",
                    children: text.description
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(CountrySelector/* default */.Z, {
                    text: text
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Waves, {})
            ]
        })
    });
}

// EXTERNAL MODULE: ./app/context/languageContext.jsx + 1 modules
var languageContext = __webpack_require__(38928);
;// CONCATENATED MODULE: ./app/components/ui/carrousel/CarrouselText.js




const CarrouselText_variants = {
    enter: (direction)=>{
        return {
            x: direction > 0 ? 1000 : -1000,
            opacity: 0,
            zindex: 0
        };
    },
    center: {
        zindex: 1,
        x: 0,
        opacity: 1
    },
    exit: (direction)=>{
        return {
            zindex: 0,
            x: direction < 0 ? 1000 : -1000,
            opacity: 0
        };
    }
};
const CarrouselText_initialIndex = 0;
function CarrouselText({ numbers , bullets , arrows , className , immagesArray , text  }) {
    const [page, setPage] = (0,react_.useState)(CarrouselText_initialIndex);
    const images = immagesArray;
    const paginationBullets = bullets || false;
    const paginationNumbers = numbers || false;
    const paginationArrows = arrows || false;
    const handleClickAfter = ()=>{
        if (page >= images.length - 1) {
            setPage(CarrouselText_initialIndex);
        } else {
            setPage((prevCount)=>prevCount + 1);
        }
    };
    const handleClickBefore = ()=>{
        if (page <= 0) {
            setPage(images.length - 1);
        } else {
            setPage((prevCount)=>prevCount - 1);
        }
    };
    (0,react_.useEffect)(()=>{
        const interval = setInterval(()=>{
            handleClickAfter();
        }, 3000);
        return ()=>clearInterval(interval);
    }, [
        page
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `${className}`,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "overflow-hidden shadow relative flex w-full min-h-[589px] md:min-h-[934px] justify-center items-center",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(AnimatePresence/* AnimatePresence */.M, {
                        initial: false,
                        custom: page,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "z-50 text-base",
                                children: text[page]
                            }),
                            images.map((image, index)=>{
                                const isCurrent = index === page;
                                const direction = index - page;
                                return /*#__PURE__*/ jsx_runtime_.jsx(motion/* motion.img */.E.img, {
                                    className: "absolute h-full w-full object-cover",
                                    src: image,
                                    custom: direction,
                                    variants: CarrouselText_variants,
                                    initial: !isCurrent ? "enter" : "center",
                                    animate: isCurrent ? "center" : "exit",
                                    exit: "exit",
                                    transition: {
                                        x: {
                                            type: "spring",
                                            stiffness: 300,
                                            damping: 30
                                        },
                                        opacity: {
                                            duration: 0.2
                                        }
                                    },
                                    drag: "x",
                                    dragConstraints: {
                                        left: 0,
                                        right: 0
                                    },
                                    dragElastic: 1,
                                    onDragEnd: (e, { offset , velocity  })=>{
                                        if (offset.x > 50) {
                                            handleClickBefore();
                                        } else if (offset.x < -50) {
                                            handleClickAfter();
                                        }
                                    }
                                }, index);
                            })
                        ]
                    }),
                    paginationArrows && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "justify-center items-center select-none cursor-pointer flex font-bold z-30 w-10 h-10 text-lg rounded-full absolute right-3 top-1/2 ",
                                onClick: handleClickAfter,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    className: "w-full h-full m-3",
                                    viewBox: "0 0 6.52 11.15",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        d: "m.43.43l5.43,4.69c.3.26.3.72,0,.98L.43,10.71",
                                        stroke: "#01ADE4",
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: "0.86px",
                                        fill: "none"
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "justify-center items-center select-none cursor-pointer flex font-bold z-30 w-10 h-10 text-lg rounded-full absolute left-3 top-1/2 -scale-100",
                                onClick: handleClickBefore,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    className: "w-full h-full m-3",
                                    viewBox: "0 0 6.52 11.15",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                                        d: "m.43.43l5.43,4.69c.3.26.3.72,0,.98L.43,10.71",
                                        stroke: "#01ADE4",
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: "0.86px",
                                        fill: "none"
                                    })
                                })
                            })
                        ]
                    })
                ]
            }),
            paginationBullets && /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "flex content-center justify-center w-full -mt-6 z-50",
                    children: images.map((image, index)=>{
                        const isCurrent = index === page;
                        return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: `z-50 bullet w-2 h-2 rounded-full bg-slate-400 mx-2 my-0 cursor-pointer ${isCurrent ? "bg-slate-200" : ""}`,
                            onClick: ()=>setPage(index)
                        }, index);
                    })
                })
            }),
            paginationNumbers && /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "flex content-center justify-center w-full z-50",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "mr-2 z-50",
                            children: page + 1
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "z-50",
                            children: "/ "
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "ml-2 z-50",
                            children: images.length
                        })
                    ]
                })
            })
        ]
    });
}
CarrouselText.propTypes = {
    heigth: (prop_types_default()).string
};

;// CONCATENATED MODULE: ./app/components/sections/SectionFourteen.jsx




function SectionFourteen({ text  }) {
    const [word, setWord] = (0,react_.useState)(text.gallery[2]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-full h-screen bg-red-400 hidden md:hidden lg:flex",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-[20%] hover:w-[25%] h-full flex justify-center bg-no-repeat bg-center bg-cover bg-activity-1",
                        style: {
                            transitionDuration: "300ms",
                            transitionProperty: "all",
                            transitionTimingFunction: "cubic-bezier(0.4, 0, 0.2, 1)"
                        },
                        onMouseEnter: ()=>setWord(text.gallery[0])
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-[20%] hover:w-[25%] bg-lime-600 h-full flex justify-center bg-no-repeat bg-center bg-cover bg-activity-2",
                        style: {
                            transitionDuration: "300ms",
                            transitionProperty: "all",
                            transitionTimingFunction: "cubic-bezier(0.4, 0, 0.2, 1)"
                        },
                        onMouseEnter: ()=>setWord(text.gallery[1])
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-[20%] hover:w-[25%] bg-lime-400 h-full flex justify-center bg-no-repeat bg-center bg-cover bg-activity-3",
                        style: {
                            transitionDuration: "300ms",
                            transitionProperty: "all",
                            transitionTimingFunction: "cubic-bezier(0.4, 0, 0.2, 1)"
                        },
                        onMouseEnter: ()=>setWord(text.gallery[2]),
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "self-center text-4xl font-normal",
                            children: word
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-[20%] hover:w-[25%] bg-lime-200 h-full flex justify-center bg-no-repeat bg-center bg-cover bg-activity-4",
                        style: {
                            transitionDuration: "300ms",
                            transitionProperty: "all",
                            transitionTimingFunction: "cubic-bezier(0.4, 0, 0.2, 1)"
                        },
                        onMouseEnter: ()=>setWord(text.gallery[3])
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-[20%] hover:w-[25%] bg-lime-100 h-full flex justify-center bg-no-repeat bg-center bg-cover bg-activity-5",
                        style: {
                            transitionDuration: "300ms",
                            transitionProperty: "all",
                            transitionTimingFunction: "cubic-bezier(0.4, 0, 0.2, 1)"
                        },
                        onMouseEnter: ()=>setWord(text.gallery[4])
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(CarrouselText, {
                bullets: true,
                className: "lg:hidden xl:hidden ",
                immagesArray: data_images/* activities */.tS,
                text: text.gallery
            })
        ]
    });
}

;// CONCATENATED MODULE: ./app/page.jsx



















function Homepage() {
    const { text  } = (0,react_.useContext)(languageContext.LanguageContext);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "max-w-full",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "grid grid-cols-1",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "z-50"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(SectionAnimation, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(SectionOne, {
                            text: [
                                text.home[0],
                                text.home[1]
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(SectionAnimation, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(SectionThree, {
                            text: text.home[2]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(SectionAnimation, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(SectionFour, {
                            text: text.home[3]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(SectionAnimation, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(SectionFive, {
                            text: text.home[4]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(SectionAnimation, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(SectionSix, {
                            text: text.home[5]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "relative w-full",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(SectionAnimation, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(SectionSeven, {
                                    text: text.home[6]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(SectionAnimation, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(SectionEight, {
                                    text: text.home[7]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full flex",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(startsBackground, {
                                    id: "stars1"
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(SectionAnimation, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(SectionNine, {
                            text: text.home[8]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(SectionAnimation, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(SectionTen, {
                            text: text.home[9]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(SectionAnimation, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(SectionEleven, {
                            text: text.home[10]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(SectionAnimation, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(SectionTwelve, {
                            text: text.home[11]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(SectionAnimation, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(SectionThirteen, {
                            text: text.home[12]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(SectionAnimation, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(SectionFourteen, {
                            text: text.home[13]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "relative w-full",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(SectionAnimation, {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(SectionFifteen_SectionFifteen, {
                                    text: text.home[14]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-full flex",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(startsBackground, {
                                    id: "stars2"
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
}


/***/ }),

/***/ 32438:
/***/ (() => {



/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [816,330,88,644], () => (__webpack_exec__(3828)));
module.exports = __webpack_exports__;

})();