(() => {
var exports = {};
exports.id = 506;
exports.ids = [506];
exports.modules = {

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 97897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 56786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 69274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 62681:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_6__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_4__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_5__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_3__.staticGenerationAsyncStorage),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(72315);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(62333);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(62885);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(90683);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(23269);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(85746);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8208);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_6__);

    const tree = {
      children: [
        '',
        {
      children: [
        'merchants',
        {
      children: ['', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 21429, 23)), "C:\\Users\\LEUM_\\Desktop\\Tangle\\Tangle-Offline-website-2023\\app\\merchants\\page.jsx"]}]
    },
        {
          'head': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 16604)), "C:\\Users\\LEUM_\\Desktop\\Tangle\\Tangle-Offline-website-2023\\app\\merchants\\head.js"],
        }
      ]
    },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 11977)), "C:\\Users\\LEUM_\\Desktop\\Tangle\\Tangle-Offline-website-2023\\app\\layout.js"],
'head': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 22725)), "C:\\Users\\LEUM_\\Desktop\\Tangle\\Tangle-Offline-website-2023\\app\\head.js"],
        }
      ]
    }.children;
    const pages = ["C:\\Users\\LEUM_\\Desktop\\Tangle\\Tangle-Offline-website-2023\\app\\merchants\\page.jsx"]

    
    
    

    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
  

/***/ }),

/***/ 72084:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 47940))

/***/ }),

/***/ 16604:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Head)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(88499);

function Head({ params  }) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
                children: "Tangle Offline - Merchants"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("meta", {
                content: "width=device-width, initial-scale=1",
                name: "viewport"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                rel: "icon",
                href: "/favicon.ico"
            })
        ]
    });
}


/***/ }),

/***/ 21429:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__ */ const { createProxy  } = __webpack_require__(14353);
module.exports = createProxy("C:\\Users\\LEUM_\\Desktop\\Tangle\\Tangle-Offline-website-2023\\app\\merchants\\page.jsx");


/***/ }),

/***/ 47940:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(56786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _emailjs_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(15366);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(71031);
/* harmony import */ var _context_languageContext__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(38928);
/* harmony import */ var framer_motion__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(94945);
/* harmony import */ var _components_ui_animation_lettersAnimation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(11296);
/* harmony import */ var _components_ui_animation_wordsAnimation__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(55644);
/* harmony import */ var _components_navbar_NavBar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(60278);
/* harmony import */ var _components_footer_Footer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(27753);


// import { Button, Col, Form, Row } from 'react-bootstrap'


// import Lottie from 'react-lottie'
// import TickAnimation from '../resources/lotties/tickAnimation.json'






const Merchant = ()=>{
    const { text  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(_context_languageContext__WEBPACK_IMPORTED_MODULE_3__.LanguageContext);
    const [formDone, setFormDone] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const form = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const [formData, setFormData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        storeName: "",
        storeAddress: "",
        businessType: "",
        websiteLink: "",
        name: "",
        lastName: "",
        emailAddress: "",
        phoneNumber: "",
        feedback: ""
    });
    const { handleSubmit  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_8__/* .useForm */ .cI)();
    const onSubmit = (event)=>{
        sendEmail(event);
    };
    const content = text;
    const player = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const [screenSize, getDimension] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        dynamicWidth: window.innerWidth,
        dynamicHeight: window.innerHeight
    });
    const setDimension = ()=>{
        getDimension({
            dynamicWidth: window.innerWidth,
            dynamicHeight: window.innerHeight
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        window.addEventListener("resize", setDimension);
        return ()=>{
            window.removeEventListener("resize", setDimension);
        };
    }, [
        screenSize
    ]);
    // const defaultOptions = {
    //   loop: false,
    //   autoplay: false,
    //   animationData: TickAnimation
    // }
    const updateFormData = (event, property)=>{
        const target = event.target;
        event.preventDefault();
        setFormData((prevState)=>({
                ...prevState,
                [property]: target.value
            }));
    };
    const sendEmail = (event)=>{
        event.preventDefault();
        setFormDone(true);
        console.log(formData);
        _emailjs_browser__WEBPACK_IMPORTED_MODULE_2__/* ["default"].send */ .ZP.send("service_g8pfoei", "template_9qrqkza", formData, "howejlV7p3kue6F_D").then((result)=>{
            console.log(result.text);
        }, (error)=>{
            console.log(error.text);
        });
        setFormData({
            storeName: "",
            storeAddress: "",
            businessType: "",
            websiteLink: "",
            name: "",
            lastName: "",
            emailAddress: "",
            phoneNumber: "",
            feedback: ""
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (player.current) {
            player.current.play();
        }
    }, [
        formDone
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "max-w-full grid grid-cols-1 mb-8",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_9__/* .motion.div */ .E.div, {
                className: "max-w-full py-6 align-middle justify-center content-center mt-20",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_animation_lettersAnimation__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    className: "text-3xl md:text-4xl lg:text-5xl font-bold text-center",
                    text: `${content.merchant[0].header[0].text}`,
                    tag: "h1"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "px-2 md:px-14 lg:px-32 w-full flex flex-col align-top justify-center content-center max-w-6xl m-auto",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "h-full grid grid-cols-1 gap-y-12 gap-x-12 lg:grid-cols-2 align-center justify-center content-center bg-tangle-oxford-blue p-8 md:p-10 rounded-2xl",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "w-full ",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: "mx-auto rounded-2xl h-[165px] md:h-[325px] lg:h-[350px] w-full bg-no-repeat bg-top lg:bg-center bg-cover bg-img-merchant"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    className: "text-center mt-4",
                                    children: content.merchant[0].description
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "p-4 bg-white rounded-2xl",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_9__/* .motion.div */ .E.div, {
                                    className: "max-w-full mb-4 ",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ui_animation_wordsAnimation__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                        className: "text-base sm:text-lg md:text-xl lg:text-2xl font-body text-tangle-rich-black-FOGBRA-29",
                                        text: content.merchant[0].form.header,
                                        tag: "p"
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    ref: form,
                                    onSubmit: (e)=>handleSubmit(onSubmit(e)),
                                    className: "grid grid-cols-1 gap-y-3 ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "text",
                                                placeholder: content.merchant[0].form.body[0].text,
                                                value: formData.storeName,
                                                onChange: (e)=>updateFormData(e, "storeName"),
                                                className: "form-input w-full rounded-lg bg-gray-200 text-black border-none h-45 placeholder:text-slate-600 px-3 py-1",
                                                required: true
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "text",
                                                placeholder: content.merchant[0].form.body[1].text,
                                                value: formData.storeAddress,
                                                onChange: (e)=>updateFormData(e, "storeAddress"),
                                                className: "form-input w-full rounded-lg bg-gray-200 text-black border-none h-45 placeholder:text-slate-600 px-3 py-1",
                                                required: true
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "text",
                                                placeholder: content.merchant[0].form.body[2].text,
                                                value: formData.businessType,
                                                onChange: (e)=>updateFormData(e, "businessType"),
                                                className: "form-input w-full rounded-lg bg-gray-200 text-black border-none h-45 placeholder:text-slate-600 px-3 py-1",
                                                required: true
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "url",
                                                placeholder: content.merchant[0].form.body[3].text,
                                                value: formData.websiteLink,
                                                onChange: (e)=>updateFormData(e, "websiteLink"),
                                                className: "form-input w-full rounded-lg bg-gray-200 text-black border-none h-45 placeholder:text-slate-600 px-3 py-1",
                                                required: true
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "grid grid-cols-2 gap-x-4 gap-y-3 mt-2",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "text",
                                                        placeholder: content.merchant[0].form.body[5].text,
                                                        value: formData.name,
                                                        onChange: (e)=>updateFormData(e, "name"),
                                                        className: "form-input w-full rounded-lg bg-gray-200 text-black border-none h-45 placeholder:text-slate-600 px-3 py-1",
                                                        required: true
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                    className: "",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                        type: "text",
                                                        placeholder: content.merchant[0].form.body[6].text,
                                                        value: formData.lastName,
                                                        onChange: (e)=>updateFormData(e, "lastName"),
                                                        className: "form-input w-full rounded-lg bg-gray-200 text-black border-none h-45 placeholder:text-slate-600 px-3 py-1",
                                                        required: true
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "email",
                                                placeholder: content.merchant[0].form.body[7].text,
                                                value: formData.emailAddress,
                                                onChange: (e)=>updateFormData(e, "emailAddress"),
                                                className: "form-input w-full rounded-lg bg-gray-200 text-black border-none h-45 placeholder:text-slate-600 px-3 py-1",
                                                required: true
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                type: "tel",
                                                placeholder: content.merchant[0].form.body[8].text,
                                                value: formData.phoneNumber,
                                                onChange: (e)=>updateFormData(e, "phoneNumber"),
                                                className: "form-input w-full rounded-lg bg-gray-200 text-black border-none h-45 placeholder:text-slate-600 px-3 py-1",
                                                required: true
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("textarea", {
                                                rows: 3,
                                                placeholder: content.merchant[0].form.body[9].text,
                                                value: formData.feedback,
                                                onChange: (e)=>updateFormData(e, "feedback"),
                                                className: "form-control w-full rounded-lg bg-gray-200 text-black border-none h-45 placeholder:text-slate-600 px-3 py-1"
                                            })
                                        }),
                                        !formDone ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(framer_motion__WEBPACK_IMPORTED_MODULE_9__/* .motion.button */ .E.button, {
                                            className: "bg-[#0086D3] rounded-lg w-full py-1",
                                            children: content.merchant[0].form.body[10].text
                                        }) : ""
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Merchant);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [816,366,88,644], () => (__webpack_exec__(62681)));
module.exports = __webpack_exports__;

})();